#!/usr/bin/env python3
"""Package a lineage-report.json into a self-contained lineage-viewer.html.

The prebuilt viewer template contains the compiled UI and a placeholder:

    __LINEAGE_REPORT_JSON__

This script replaces the placeholder with the report JSON. If the placeholder is
missing, it inserts a script before the viewer bundle.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("report", help="Path to lineage-report.json")
    parser.add_argument("output", help="Path to write lineage-viewer.html")
    parser.add_argument(
        "--template",
        default=str(Path(__file__).resolve().parents[1] / "viewer-template" / "prebuilt-viewer-template.html"),
        help="Path to prebuilt viewer template"
    )
    args = parser.parse_args()

    report_path = Path(args.report)
    template_path = Path(args.template)
    output_path = Path(args.output)

    report = json.loads(report_path.read_text(encoding="utf-8"))
    report_json = json.dumps(report, ensure_ascii=False).replace("</script", "<\\/script")

    html = template_path.read_text(encoding="utf-8")
    injection = f'<script id="lineage-report-injection">window.__LINEAGE_REPORT__ = {report_json};</script>'

    if "__LINEAGE_REPORT_JSON__" in html:
        html = html.replace("__LINEAGE_REPORT_JSON__", report_json)
    elif "window.__LINEAGE_REPORT__" not in html:
        html = html.replace('<div id="root"></div>', '<div id="root"></div>\n' + injection, 1)
    else:
        # Template has a sample fallback but no explicit placeholder. Insert runtime report before the module script.
        html = html.replace('<div id="root"></div>', '<div id="root"></div>\n' + injection, 1)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    print(f"wrote {output_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
