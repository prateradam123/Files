#!/usr/bin/env python3
"""Validate the Outbound Payload Lineage report contract.

This validator is intentionally stricter than the viewer. The viewer can render
partial reports, but a production-quality lineage run should pass these checks.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

TERMINAL_KINDS = {"repository", "event", "external", "config", "constant", "runtime", "unknown"}
ROLE_HINTS = [
    "read from", "loaded by", "supplies", "input", "computed from", "transform input",
    "predicate", "condition", "controls", "override", "fallback", "lookup key",
    "default", "constant", "generated", "runtime", "unresolved"
]
VALUE_RESOLUTION_TYPES = {"conditional", "fallback", "dynamic", "unknown", "gap"}


class Validation:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []

    def err(self, msg: str) -> None:
        self.errors.append(msg)

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)


def walk_shape(node: dict[str, Any], out: list[dict[str, Any]]) -> None:
    out.append(node)
    for child in node.get("children", []) or []:
        walk_shape(child, out)


def leaf_paths(shape: dict[str, Any]) -> set[str]:
    nodes: list[dict[str, Any]] = []
    walk_shape(shape, nodes)
    return {n["path"] for n in nodes if n.get("kind") == "field"}


def validate(report: dict[str, Any]) -> Validation:
    v = Validation()

    for key in ["object", "objectShape", "fields"]:
        if key not in report:
            v.err(f"missing required top-level key: {key}")

    if "objectShape" not in report or "fields" not in report:
        return v

    shape_leaves = leaf_paths(report["objectShape"])
    fields = report.get("fields", [])
    field_by_path: dict[str, dict[str, Any]] = {}

    for field in fields:
        path = field.get("path")
        if not path:
            v.err("field missing path")
            continue
        if path in field_by_path:
            v.err(f"duplicate field report: {path}")
        field_by_path[path] = field

    missing = sorted(shape_leaves - set(field_by_path))
    extra = sorted(set(field_by_path) - shape_leaves)
    for path in missing:
        v.err(f"objectShape leaf has no field report: {path}")
    for path in extra:
        v.warn(f"field report not found in objectShape leaves: {path}")

    gap_fields = {g.get("field") for g in report.get("gaps", []) or []}

    for field in fields:
        path = field.get("path", "<unknown>")
        for key in ["confidence", "mappingType", "description", "lineage"]:
            if key not in field:
                v.err(f"{path}: missing {key}")

        lineage = field.get("lineage") or {}
        nodes = lineage.get("nodes") or []
        edges = lineage.get("edges") or []
        node_ids = {n.get("id") for n in nodes if n.get("id")}

        if not nodes:
            v.err(f"{path}: lineage.nodes is empty")
        if not edges:
            v.warn(f"{path}: lineage.edges is empty")

        for n in nodes:
            for key in ["id", "kind", "title", "tier", "row"]:
                if key not in n:
                    v.err(f"{path}: lineage node missing {key}: {n}")
            if n.get("kind") in TERMINAL_KINDS:
                incoming_labels = [e[2] for e in edges if len(e) >= 3 and e[1] == n.get("id")]
                role_text = " ".join(incoming_labels + [str(n.get("sourceRole", ""))]).lower()
                if not any(hint in role_text for hint in ROLE_HINTS):
                    v.warn(f"{path}: terminal source '{n.get('title')}' has vague role labels; Source Map may be less useful")

        for e in edges:
            if not isinstance(e, list) or len(e) != 3:
                v.err(f"{path}: edge must be [from, to, label]: {e}")
                continue
            src, dst, label = e
            if src != "FIELD" and src not in node_ids:
                v.err(f"{path}: edge source references missing node: {src}")
            if dst != "FIELD" and dst not in node_ids:
                v.err(f"{path}: edge target references missing node: {dst}")
            if not str(label).strip():
                v.err(f"{path}: edge label is empty: {e}")

        mapping = str(field.get("mappingType", "")).lower()
        terminal_count = sum(1 for n in nodes if n.get("kind") in TERMINAL_KINDS)
        if terminal_count == 0 and path not in gap_fields and mapping not in {"gap", "unknown"}:
            v.warn(f"{path}: no terminal source boundary; Source Map will not show this field")

        needs_resolution = mapping in VALUE_RESOLUTION_TYPES or len([n for n in nodes if n.get("kind") == "resolution"]) > 0
        if needs_resolution and "valueResolution" not in field:
            v.warn(f"{path}: {mapping} field should include valueResolution")

        vr = field.get("valueResolution")
        if vr:
            if not vr.get("summary"):
                v.err(f"{path}: valueResolution missing summary")
            if mapping in {"conditional", "fallback"} and not vr.get("finalRule"):
                v.warn(f"{path}: {mapping} field should include valueResolution.finalRule")
            assignment_ids = {a.get("id") for a in vr.get("assignments", []) or [] if a.get("id")}
            node_assignment_ids = {n.get("assignmentId") for n in nodes if n.get("assignmentId")}
            missing_assignment_nodes = assignment_ids - node_assignment_ids
            if missing_assignment_nodes:
                v.warn(f"{path}: valueResolution assignments not linked from lineage nodes by assignmentId: {sorted(missing_assignment_nodes)}")

    for gap in report.get("gaps", []) or []:
        field = gap.get("field")
        if not field:
            v.err("gap missing field")
        elif field not in field_by_path:
            v.warn(f"gap references field not in fields[]: {field}")
        for key in ["severity", "reason", "recommendation"]:
            if not gap.get(key):
                v.err(f"{field}: gap missing {key}")

    return v


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("report")
    parser.add_argument("--warnings-as-errors", action="store_true")
    args = parser.parse_args()

    report = json.loads(Path(args.report).read_text(encoding="utf-8"))
    result = validate(report)

    for warning in result.warnings:
        print(f"WARN: {warning}")
    for error in result.errors:
        print(f"FAIL: {error}")

    print(f"validation: {len(result.errors)} error(s), {len(result.warnings)} warning(s)")
    if result.errors or (args.warnings_as_errors and result.warnings):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
