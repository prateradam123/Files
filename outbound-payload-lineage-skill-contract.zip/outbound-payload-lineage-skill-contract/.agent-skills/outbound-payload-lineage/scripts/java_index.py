#!/usr/bin/env python3
"""Lightweight deterministic Java evidence indexer.

This is not a full Java parser. It is a fast, repeatable first pass that gives
the agent compact evidence to reason over.

It records:
- Java files
- packages/imports/classes
- likely methods
- likely fields
- outbound send surfaces
- mapper/copy utility calls
- repository/client/config boundary hints
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

JAVA_EXT = ".java"

CLASS_RE = re.compile(r"\b(class|record|interface|enum)\s+([A-Z][A-Za-z0-9_]*)")
PACKAGE_RE = re.compile(r"^\s*package\s+([A-Za-z0-9_.]+)\s*;", re.M)
IMPORT_RE = re.compile(r"^\s*import\s+([A-Za-z0-9_.*]+)\s*;", re.M)
METHOD_RE = re.compile(r"(?:public|protected|private|static|final|synchronized|\s)+\s*([A-Za-z0-9_<>\[\].?,\s]+)\s+([a-zA-Z_][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*(?:throws [^{]+)?\{")
FIELD_RE = re.compile(r"(?:private|protected|public)\s+(?:final\s+)?([A-Za-z0-9_<>\[\].?,\s]+)\s+([a-zA-Z_][A-Za-z0-9_]*)\s*(?:=|;)")
OUTBOUND_PATTERNS = [
    ("rest_template", re.compile(r"\b(restTemplate|RestTemplate)\s*\.\s*(postForEntity|exchange|postForObject)\s*\(")),
    ("web_client", re.compile(r"\b(webClient|WebClient)\s*\.\s*(post|put|patch)\s*\(")),
    ("kafka", re.compile(r"\b(kafkaTemplate|KafkaTemplate)\s*\.\s*send\s*\(")),
    ("jms", re.compile(r"\b(jmsTemplate|JmsTemplate)\s*\.\s*(convertAndSend|send)\s*\(")),
    ("repository_save", re.compile(r"\b([a-zA-Z0-9_]*Repository)\s*\.\s*save\s*\(")),
    ("generic_send", re.compile(r"\b(send|publish|dispatch|post|submit)\s*\(")),
]
BOUNDARY_HINTS = [
    ("repository", re.compile(r"\b[A-Za-z0-9_]*Repository\b|\b@Repository\b")),
    ("external", re.compile(r"\b(RestTemplate|WebClient|FeignClient|Client|Api)\b")),
    ("config", re.compile(r"@Value\b|@ConfigurationProperties\b|application\.ya?ml|Properties\b")),
    ("dynamic_mapping", re.compile(r"BeanUtils\.copyProperties|PropertyUtils|ModelMapper|MapStruct|@Mapper\b")),
]


def line_number(text: str, index: int) -> int:
    return text.count("\n", 0, index) + 1


def snippets(text: str, pattern: re.Pattern) -> list[dict]:
    result = []
    for m in pattern.finditer(text):
        line = line_number(text, m.start())
        raw_line = text.splitlines()[line - 1].strip()
        result.append({"line": line, "snippet": raw_line})
    return result


def index_file(path: Path, root: Path) -> dict:
    text = path.read_text(encoding="utf-8", errors="ignore")
    rel = str(path.relative_to(root))
    classes = [m.group(2) for m in CLASS_RE.finditer(text)]
    methods = [
        {"name": m.group(2), "returnType": " ".join(m.group(1).split()), "line": line_number(text, m.start())}
        for m in METHOD_RE.finditer(text)
    ]
    fields = [
        {"name": m.group(2), "type": " ".join(m.group(1).split()), "line": line_number(text, m.start())}
        for m in FIELD_RE.finditer(text)
    ]
    outbound = []
    for kind, pat in OUTBOUND_PATTERNS:
        for item in snippets(text, pat):
            outbound.append({"kind": kind, **item})
    boundaries = []
    for kind, pat in BOUNDARY_HINTS:
        hits = snippets(text, pat)
        if hits:
            boundaries.append({"kind": kind, "hits": hits[:10]})
    return {
        "file": rel,
        "package": (PACKAGE_RE.search(text).group(1) if PACKAGE_RE.search(text) else None),
        "imports": IMPORT_RE.findall(text),
        "classes": classes,
        "methods": methods,
        "fields": fields,
        "outboundCandidates": outbound,
        "boundaryHints": boundaries,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root")
    parser.add_argument("--out", default="lineage-evidence.json")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    files = [p for p in root.rglob(f"*{JAVA_EXT}") if "target/" not in str(p) and "build/" not in str(p)]
    indexed = [index_file(p, root) for p in files]

    evidence = {
        "projectRoot": str(root),
        "fileCount": len(files),
        "files": indexed,
        "outboundSurfaces": [
            {"file": f["file"], **candidate}
            for f in indexed
            for candidate in f["outboundCandidates"]
        ],
        "boundaryHintFiles": [
            {"file": f["file"], "hints": f["boundaryHints"]}
            for f in indexed
            if f["boundaryHints"]
        ],
    }

    Path(args.out).write_text(json.dumps(evidence, indent=2), encoding="utf-8")
    print(f"indexed {len(files)} Java files -> {args.out}")
    print(f"found {len(evidence['outboundSurfaces'])} outbound candidates")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
