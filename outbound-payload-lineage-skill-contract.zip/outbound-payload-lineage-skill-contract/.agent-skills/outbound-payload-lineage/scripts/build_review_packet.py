#!/usr/bin/env python3
"""Build a compact review packet for a bounded agent audit.

The agent should review this packet instead of re-tracing the whole repo.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

TERMINAL_KINDS = {"repository", "event", "external", "config", "constant", "runtime", "unknown"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("report")
    parser.add_argument("output")
    args = parser.parse_args()

    report = json.loads(Path(args.report).read_text(encoding="utf-8"))
    fields = report.get("fields", [])
    gaps = report.get("gaps", []) or []

    suspicious = []
    for f in fields:
        path = f.get("path")
        mapping = f.get("mappingType")
        nodes = f.get("lineage", {}).get("nodes", [])
        terminal_nodes = [n for n in nodes if n.get("kind") in TERMINAL_KINDS]
        resolution = f.get("valueResolution")

        reasons = []
        if mapping in {"conditional", "fallback", "dynamic", "unknown", "gap"}:
            reasons.append(f"mappingType={mapping}")
        if len([n for n in nodes if n.get("kind") == "assignment"]) > 1 and not resolution:
            reasons.append("multiple assignment nodes but no valueResolution")
        if not terminal_nodes and mapping not in {"gap", "unknown"}:
            reasons.append("no terminal source boundary")
        if any(n.get("kind") == "unknown" for n in nodes):
            reasons.append("unknown terminal node")
        if resolution and not resolution.get("finalRule") and mapping in {"conditional", "fallback"}:
            reasons.append("missing finalRule")

        if reasons:
            suspicious.append({
                "field": path,
                "mappingType": mapping,
                "confidence": f.get("confidence"),
                "reasons": reasons,
                "description": f.get("description"),
                "valueResolution": resolution,
                "terminalSources": [
                    {
                        "id": n.get("id"),
                        "kind": n.get("kind"),
                        "title": n.get("title"),
                        "meta": n.get("meta"),
                        "sourceRole": n.get("sourceRole")
                    }
                    for n in terminal_nodes
                ]
            })

    packet = {
        "target": report.get("object", {}),
        "coverage": {
            "fields": len(fields),
            "gaps": len(gaps),
            "suspicious": len(suspicious),
        },
        "reviewInstructions": [
            "Do not re-trace the whole repository.",
            "Review only suspicious items and source role/finalRule correctness.",
            "Flag unsupported summaries, missing valueResolution, incorrect source roles, or suspicious gaps.",
            "Use PASS/WARN/FAIL with concrete evidence."
        ],
        "suspiciousItems": suspicious,
        "gaps": gaps,
    }

    Path(args.output).write_text(json.dumps(packet, indent=2), encoding="utf-8")
    print(f"wrote {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
