# Usage

From the skill directory:

```bash
python scripts/java_index.py /path/to/project --out lineage-evidence.json
python scripts/validate_lineage_report.py lineage-report.json
python scripts/build_review_packet.py lineage-report.json lineage-review.json
python scripts/package_viewer.py lineage-report.json lineage-viewer.html
```

The deterministic scripts are intentionally lightweight. They collect repeatable evidence and validate the report contract. They do not replace agent reasoning for semantic cases like final winner rules, dynamic mapping, source role interpretation, or business-readable summaries.
