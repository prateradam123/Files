# Lineage Report Contract

The viewer is intentionally dumb: it displays a report. The skill must create a complete report contract.

## Required concepts

### 1. `objectShape`

Nested DTO/message structure. This powers:
- hierarchy panel
- Shape view
- object/subtree graph mode
- breadcrumbs
- coverage validation

Every leaf field in `objectShape` must have a matching item in `fields[]`, unless it is explicitly excluded in a review/gap artifact.

### 2. `fields[]`

One record per output leaf field.

Each field must include:
- `path`
- `confidence`
- `mappingType`
- `description`
- `lineage.nodes`
- `lineage.edges`

### 3. Source Map support

Source Map is derived from terminal source nodes in each field lineage.

Terminal source node kinds are:
- `event`
- `repository`
- `external`
- `config`
- `constant`
- `runtime`
- `unknown`

For Source Map to be useful, every terminal source must be connected by an edge label that explains its role. Prefer these labels:

| Role | Edge label examples |
|---|---|
| supplies value | `read from`, `loaded by`, `supplies value` |
| supplies transform input | `input`, `computed from`, `transform input` |
| controls condition | `predicate input`, `condition source`, `controls branch` |
| controls override | `controls override`, `override condition` |
| fallback candidate | `fallback candidate`, `fallback value`, `default fallback` |
| lookup key | `lookup key`, `uses key` |
| default value | `default`, `enum constant`, `hardcoded default` |

You may also set `sourceRole` on the terminal node or `sourceRoles[]` on assignments, but the graph still needs role-bearing edges.

### 4. `valueResolution`

Required when a field is:
- conditional
- fallback
- overwritten/multi-write
- defaulted then replaced
- dynamically copied
- derived from multiple inputs

The UI uses this for assignment stacks and branch focus.

### 5. Business-readable summaries

`description`, `valueResolution.summary`, and `valueResolution.finalRule` should be short and evidence-backed. The agent may write these, but every claim must be grounded in candidate assignments, conditions, source nodes, or gaps.

### 6. Gaps

A gap is valid only when the skill cannot statically determine a source after deterministic scan plus targeted agent review.

Every gap must include:
- `field`
- `severity`
- `reason`
- `recommendation`

Examples:
- dynamic `BeanUtils.copyProperties`
- reflection
- generated source unavailable
- MapStruct generated impl missing
- third-party dependency boundary
- runtime object mutation not reachable statically
