# Outbound Payload Lineage Skill

Use this skill to trace an outbound object/payload/message from the point it leaves the system back to its earliest reachable data origins.

The goal is not only to draw a graph. The goal is to produce a complete, validated `lineage-report.json` that supports:

- field lineage view
- object/subtree lineage view
- shape view
- Source Map view
- source inventory panel
- value-resolution assignment stack
- gaps/review panel
- business-readable summaries

## Operating principle

Do not ask the model to understand the whole repository from scratch.

Use a hybrid workflow:

```text
deterministic scripts gather facts and candidates
agent resolves semantic/ambiguous cases
deterministic validator checks report contract
viewer packaging displays the result
```

The agent should reason over evidence packets, not invent lineage.

## Standard workflow

1. Identify the target outbound surface.
   - HTTP client call
   - Kafka/JMS/MQ producer send
   - controller response
   - vendor client call
   - repository save when persisted output is the target
   - any method where the output object leaves this bounded context

2. Run deterministic indexing/candidate extraction.
   Recommended scripts:
   - `scripts/java_index.py`
   - `scripts/validate_lineage_report.py`
   - `scripts/build_review_packet.py`

3. Build the report draft.
   The report must follow `schema/lineage-report.schema.json`.

4. Resolve only hard cases with the agent.
   The agent should focus on:
   - source role semantics
   - conditional/fallback final winner rules
   - dynamic mapper gaps
   - helper method business meaning
   - suspicious missing fields
   - whether a source supplies a value vs controls a branch

5. Run validation.
   ```bash
   python scripts/validate_lineage_report.py lineage-report.json
   ```

6. Build review packet.
   ```bash
   python scripts/build_review_packet.py lineage-report.json lineage-review.json
   ```

7. Package viewer.
   ```bash
   python scripts/package_viewer.py lineage-report.json lineage-viewer.html
   ```

## Required output files

For every run, produce:

```text
lineage-report.json
lineage-report.md
lineage-review.json
lineage-viewer.html
```

## Mandatory report contract

For every leaf field in `objectShape`, `fields[]` must contain exactly one field report.

Each field report must include:

```json
{
  "path": "decision.status",
  "confidence": "medium",
  "mappingType": "conditional",
  "description": "Short evidence-backed business meaning.",
  "lineage": {
    "nodes": [],
    "edges": []
  },
  "valueResolution": {}
}
```

## Source Map requirements

The Source Map view is generated from terminal source nodes in field lineage.

Terminal source node kinds:
- `event`
- `repository`
- `external`
- `config`
- `constant`
- `runtime`
- `unknown`

For every source-to-field relationship, encode the role through the edge label and/or node metadata.

Use these role concepts:

```text
supplies value
supplies transform input
controls condition
controls override
fallback candidate
lookup key
default value
required source
unknown
```

Example for multiple sources deciding one field:

```json
{
  "path": "decision.status",
  "mappingType": "conditional",
  "lineage": {
    "nodes": [
      { "id": "assign-default", "kind": "assignment", "title": "setStatus(PENDING)", "tier": 0, "row": 0, "assignmentId": "status-default" },
      { "id": "decision", "kind": "external", "title": "DecisionEngineClient.evaluate(...)", "tier": 2, "row": -1, "sourceRole": "controls_condition" },
      { "id": "hold", "kind": "repository", "title": "ComplianceHoldRepository.existsActiveHold(...)", "tier": 2, "row": 1, "sourceRole": "controls_override" },
      { "id": "enum", "kind": "constant", "title": "DecisionStatus enum constants", "tier": 2, "row": 0, "sourceRole": "default_value" }
    ],
    "edges": [
      ["FIELD", "assign-default", "assigned by"],
      ["assign-default", "enum", "default value"],
      ["assign-approved", "decision", "controls branch"],
      ["assign-review", "hold", "controls override"]
    ]
  }
}
```

The Source Map should then show all contributing sources flowing into `decision.status`.

## Value resolution requirements

If a field has more than one possible assignment, fallback, branch, default, or overwrite, include `valueResolution`.

Required modes:
- `single_assignment`
- `derived`
- `conditional_branch`
- `fallback_chain`
- `multi_write_override`
- `dynamic`
- `unknown`

Example:

```json
{
  "valueResolution": {
    "mode": "multi_write_override",
    "summary": "Status starts as PENDING, can become APPROVED/DECLINED, and can later be overwritten by MANUAL_REVIEW.",
    "finalRule": "MANUAL_REVIEW wins if active compliance hold exists; otherwise decision engine outcome wins; otherwise PENDING remains.",
    "assignments": [
      {
        "id": "status-default",
        "order": 1,
        "kind": "default",
        "label": "setStatus(PENDING)",
        "value": "PENDING",
        "condition": null,
        "sourceRoles": [{ "sourceNodeId": "enum", "role": "default_value" }]
      }
    ]
  }
}
```

## Agent review pass

After deterministic output is created, the agent must perform a bounded review, not a full duplicate trace.

Review for:
- missing field coverage
- suspicious gaps
- wrong source roles
- unsupported summaries
- missing valueResolution for conditional/fallback/multi-write fields
- fields labeled direct that call helpers/formatters/resolvers
- terminal sources with vague edge labels

Do not re-trace the entire repo unless validation or review flags a specific field.

## Done criteria

A lineage run is complete only when:

```text
validate_lineage_report.py passes
lineage-review.json has no FAIL items
lineage-viewer.html opens and displays root object by default
```
