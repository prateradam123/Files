# Outbound Payload Lineage Skill Contract Package

Install/copy `.agent-skills/outbound-payload-lineage` into your agent skills directory.

This version includes:
- strict lineage report contract
- Source Map requirements
- value-resolution requirements
- bounded agent review workflow
- validation script
- viewer packaging script
- lightweight Java evidence indexer
- example lineage report, review packet, and packaged viewer
