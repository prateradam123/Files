# Brain Memory

This repo uses a lightweight Copilot brain memory system.

The goal is to help Copilot recall durable lessons, patterns, traps, and validation knowledge without loading a giant knowledge base.

## Daily model

```text
fresh meaningful session
→ prime-session once for compact baseline repo context
→ concrete non-trivial task
→ targeted task recall as the flagship workflow
→ agent works normally and verifies against current code
→ agent submits durable learnings if anything useful was learned
→ memory.py routes proposal to active, merged, held, or rejected
```

Memory is a hint, not truth. Current source code wins.

Task recall is the primary feature. Prime-session is only a baseline orientation helper for fresh agent contexts and must not replace task-specific recall.

Use memory for code archaeology too: when asking why code exists, why a design choice was made, or whether a non-obvious workaround can be removed, recall first and verify the rationale against current code/tests/evidence.

## Commands

```bash
python -S .github/skills/brain-memory/memory.py init
python -S .github/skills/brain-memory/memory.py rebuild
python -S .github/skills/brain-memory/memory.py prime-session
python -S .github/skills/brain-memory/memory.py recall --query "<task>" --budget small
python -S .github/skills/brain-memory/memory.py learn --type trap --repo-id "<repo>" --scope repo --namespace "implementation.data-mapping" --claim "..." --why "..." --evidence "..."
python -S .github/skills/brain-memory/memory.py stats
python -S .github/skills/brain-memory/memory.py review
```

## Slash prompts

- `/brain-prime`: seed starter memories from an existing repo
- `/brain-prime-session`: orient a fresh agent/session with compact baseline repo context
- `/brain-scan`: scan recent work for anything memory-worthy
- `/brain-review`: rare review of held/noisy/stale/contradictory memories

## Folders

- `memories/`: active, quiet, or superseded memories
- `held/`: proposals that need review or explicit scope approval
- `rejected/`: rejected proposals retained for audit/dedupe
- `feedback/`: recall feedback signals
- `index/`: generated SQLite index, ignored by git
- `local/`: local/session files, ignored by git

## Version control

Commit memory source files:

```text
.ai/brain/config.json
.ai/brain/memories/
.ai/brain/held/
.ai/brain/rejected/
.ai/brain/feedback/
```

Do not commit generated/local files:

```text
.ai/brain/index/
.ai/brain/local/
```

Rebuild the index anytime:

```bash
python -S .github/skills/brain-memory/memory.py rebuild
```


## Rationale recall

For explicit why/intent questions, use:

```bash
python -S .github/skills/brain-memory/memory.py recall --query "why is <behavior> done this way" --task-type rationale --budget small
```

For removal, simplification, modernization, or refactoring of non-obvious code, use:

```bash
python -S .github/skills/brain-memory/memory.py recall --query "can <behavior> be removed or simplified" --task-type refactoring --budget medium
```

Recalled rationale is a hypothesis. Verify it before explaining intent or changing behavior.

## Evidence portability

Evidence should be repo-relative whenever possible. The memory tool accepts existing repo-relative paths, inside-repo absolute paths, and prefixed evidence such as `commit:<sha>`, `command:<command>`, or `note:<text>`. Outside-repo or missing file paths are held for review instead of being auto-promoted.
