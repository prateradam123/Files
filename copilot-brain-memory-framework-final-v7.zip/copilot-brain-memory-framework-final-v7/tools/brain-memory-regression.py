#!/usr/bin/env python3
import json, re, shutil, subprocess, sys, time, tempfile
from pathlib import Path

SRC=Path(__file__).resolve().parents[1]
BASE=Path(tempfile.mkdtemp(prefix='brain-memory-regression-'))
PY=sys.executable
SCRIPT='.github/skills/brain-memory/memory.py'
PY_CMD=[PY, '-S']

passed=failed=0; failures=[]
def check(name, cond, detail=''):
    global passed, failed
    if cond:
        passed+=1; print('PASS', name, flush=True)
    else:
        failed+=1; failures.append((name, detail)); print('FAIL', name, detail[:500], flush=True)

def run(args, input=None, timeout=30, checkrc=False):
    if isinstance(args, str):
        cmd=args; shell=True
        label=args
    else:
        cmd=args; shell=False
        label=' '.join(str(x) for x in args[:5])
    # Keep the long regression suite visibly progressing in agent/tool environments.
    print('RUN', label, flush=True)
    res=subprocess.run(cmd, cwd=BASE, text=True, capture_output=True, input=input, timeout=timeout, shell=shell)
    print('DONE', label, 'rc='+str(res.returncode), flush=True)
    if checkrc and res.returncode!=0:
        raise AssertionError((args,res.returncode,res.stdout,res.stderr))
    return res

def mem(args, input=None, timeout=30):
    return run(PY_CMD+[SCRIPT]+args, input=input, timeout=timeout)

def setup():
    if BASE.exists(): shutil.rmtree(BASE)
    shutil.copytree(SRC, BASE)
    for d in ['src/main/java/com/acme/order','src/main/resources','src/test/java/com/acme/order','src/test/resources/features']:
        (BASE/d).mkdir(parents=True, exist_ok=True)
    files={
      'src/main/java/com/acme/order/RoutingPayloadBuilder.java':'class RoutingPayloadBuilder { void build(){ StatusNormalizer n; } }',
      'src/main/java/com/acme/order/StatusNormalizer.java':'class StatusNormalizer { String normalize(String s){ return s; } }',
      'src/main/java/com/acme/order/RetryScheduler.java':'class RetryScheduler { RetryStateRepository repo; }',
      'src/main/java/com/acme/order/RetryStateRepository.java':'class RetryStateRepository {}',
      'src/main/resources/order-routing-map.xml':'<map><field name="status"/></map>',
      'src/test/java/com/acme/order/OrderRoutingComponentTest.java':'class OrderRoutingComponentTest {}',
      'src/test/resources/features/order-routing.feature':'Feature: order routing',
    }
    for k,v in files.items(): (BASE/k).write_text(v)
    run('git init -q',checkrc=True)
    run('git config user.email test@example.com && git config user.name Tester', checkrc=True)
    run('git add . && git commit -q -m initial', checkrc=True)

def ids(folder):
    return [json.loads(p.read_text())['id'] for p in sorted((BASE/folder).glob('*.json'))]

def learn(**kw):
    args=['learn']
    for k,v in kw.items():
        args.append('--'+k.replace('_','-'))
        args.append(v)
    return mem(args, timeout=45)

def get_id(prefix, out):
    m=re.search(prefix+r' (mem-[^ ]+)', out)
    return m.group(1) if m else ''

setup()
start=time.time()
check('init', mem(['init']).returncode==0)
check('index exists', (BASE/'.ai/brain/index/memory.sqlite').exists())
r=mem(['recall','--query','status mapping','--budget','small'])
check('empty recall optional', 'No relevant memories found' in r.stdout)

r=learn(type='trap', repo_id='order-routing-demo', scope='repo', namespace='implementation.data-mapping', claim='Status fields may be normalized after the initial DTO mapping before payload dispatch', why='Future mapping investigations should check post-mapping normalization before assuming the mapped status is final', confidence='likely', tags='status,normalizer,mapping,overwrite', task_types='data-mapping,debugging', entities='RoutingPayloadBuilder,StatusNormalizer', evidence='src/main/java/com/acme/order/RoutingPayloadBuilder.java,src/main/java/com/acme/order/StatusNormalizer.java')
check('repo promote', 'promoted' in r.stdout, r.stdout)
mem1=get_id('promoted', r.stdout)
r=mem(['recall','--repo-id','order-routing-demo','--query','where does status get mapped and normalized','--budget','small'])
check('recall promoted', mem1 in r.stdout and 'Status fields may be normalized' in r.stdout, r.stdout)

r=learn(type='lesson', repo_id='order-routing-demo', scope='repo', namespace='implementation.rationale', claim='RetryScheduler persists retry state so delivery timing survives process restarts instead of depending on broker retry timing', why='Future code archaeology should recall this before removing the persisted retry path or assuming broker retry owns scheduling', confidence='confirmed', tags='retry,rationale,persistence,scheduler', task_types='rationale,refactoring,debugging', entities='RetryScheduler,RetryStateRepository', evidence='src/main/java/com/acme/order/RetryScheduler.java,src/main/java/com/acme/order/RetryStateRepository.java')
rationale_id=get_id('promoted', r.stdout)
check('rationale memory promote', bool(rationale_id), r.stdout)
r=mem(['recall','--repo-id','order-routing-demo','--query','why is retry state persisted instead of broker retry','--budget','small'])
check('rationale auto recall', rationale_id in r.stdout and 'Expanded terms' in r.stdout and 'RetryScheduler persists retry state' in r.stdout, r.stdout)
r=mem(['recall','--repo-id','order-routing-demo','--query','can RetryScheduler persisted state be removed or simplified','--budget','small'])
check('refactoring rationale recall', rationale_id in r.stdout and 'RetryScheduler persists retry state' in r.stdout, r.stdout)

r=learn(type='pattern', repo_id='order-routing-demo', scope='repo', namespace='architecture.flow', claim='Order routing flows through payload building and persisted retry scheduling before dispatch completion', why='Fresh agent contexts should understand the baseline flow before planning broad routing or dispatch changes', confidence='confirmed', tags='architecture,flow,dispatch,retry', task_types='implementation,architecture', entities='RoutingPayloadBuilder,RetryScheduler', evidence='src/main/java/com/acme/order/RoutingPayloadBuilder.java,src/main/java/com/acme/order/RetryScheduler.java')
arch_id=get_id('promoted', r.stdout)
check('prime architecture memory promote', bool(arch_id), r.stdout)
r=learn(type='validation', repo_id='order-routing-demo', scope='repo', namespace='testing.component', claim='Order routing behavior is primarily validated by OrderRoutingComponentTest and feature scenarios', why='Fresh agent contexts should know the core validation path before making routing or payload changes', confidence='confirmed', tags='component,test,validation,routing', task_types='testing,validation', entities='OrderRoutingComponentTest', evidence='src/test/java/com/acme/order/OrderRoutingComponentTest.java,src/test/resources/features/order-routing.feature')
validation_id=get_id('promoted', r.stdout)
check('prime validation memory promote', bool(validation_id), r.stdout)
prime=mem(['prime-session','--repo-id','order-routing-demo','--limit','8']).stdout
check('prime session runs', '# Brain Prime Session' in prime and 'Prime-session does not replace recall' in prime, prime)
check('prime includes baseline memories', arch_id in prime and validation_id in prime and rationale_id in prime, prime)
check('prime directs task recall as flagship', 'task-specific brain recall remains the flagship' in prime.lower() and 'run `memory.py recall' in prime, prime)

check('generic reject', 'rejected' in learn(type='lesson', repo_id='order-routing-demo', scope='repo', namespace='implementation.patterns', claim='Use good error handling', why='This is generic advice and should not be accepted', confidence='likely', evidence='src/main/java/com/acme/order/RoutingPayloadBuilder.java').stdout)
r=learn(type='pattern', repo_id='order-routing-demo', scope='repo', namespace='integration.database', claim='Retry scheduling depends on persisted retry state after the message is accepted', why='Future retry debugging should inspect persisted retry state before assuming message retry controls the timing', confidence='likely', tags='retry,persistence,scheduler', task_types='debugging,integration')
check('missing evidence held', 'held' in r.stdout and 'missing' in r.stdout, r.stdout); held_missing=get_id('held',r.stdout)
r=learn(type='pattern', repo_id='order-routing-demo', scope='workspace', namespace='integration.database', claim='Related services may use persisted retry state after message acceptance for delivery scheduling', why='Cross-repo retry investigations should verify retry state tables before assuming broker retry controls timing', confidence='likely', tags='retry,persistence,scheduler', task_types='debugging,integration', evidence='src/main/java/com/acme/order/RetryScheduler.java')
check('workspace held', 'workspace_scope_requires_review' in r.stdout, r.stdout); workspace=get_id('held',r.stdout)
r=learn(type='lesson', repo_id='order-routing-demo', scope='global', namespace='agent.behavior', claim='Current source code must override recalled memory whenever the two conflict', why='This prevents stale memories from being treated as project truth during future agent work', confidence='confirmed', tags='memory,truth,verification', task_types='agent')
check('global held', 'global_scope_requires_manual_promotion' in r.stdout, r.stdout); globalid=get_id('held',r.stdout)
prime_after_held=mem(['prime-session','--repo-id','order-routing-demo','--limit','12']).stdout
check('prime excludes held workspace global proposals', held_missing not in prime_after_held and workspace not in prime_after_held and globalid not in prime_after_held, prime_after_held)
check('prime still does not replace recall after helds', 'Prime-session does not replace recall' in prime_after_held and 'task-specific brain recall remains the flagship' in prime_after_held.lower(), prime_after_held)
check('safe security guidance not rejected', 'rejected' not in learn(type='trap', repo_id='order-routing-demo', scope='global', namespace='security.data-safety', claim='Do not store API token values in brain memory records or evidence fields', why='Memory files are committed with the repository and must not contain secret material', confidence='confirmed', tags='security,memory,secrets', task_types='agent,security', evidence='note:security guidance').stdout)
check('unsafe secret rejected', 'possible_secret_or_sensitive_data' in learn(type='trap', repo_id='order-routing-demo', scope='repo', namespace='security.data-safety', claim='The integration token is token=abcd1234567890 and should be remembered', why='This intentionally contains a token-like value and should be blocked', confidence='likely', tags='security', evidence='src/main/java/com/acme/order/RoutingPayloadBuilder.java').stdout)
check('duplicate merged', 'merged' in learn(type='trap', repo_id='order-routing-demo', scope='repo', namespace='implementation.data-mapping', claim='Mapped status values can be changed by StatusNormalizer after RoutingPayloadBuilder sets them', why='Future data mapping investigations should inspect normalization after the builder path before trusting the initial mapped status', confidence='likely', tags='status,normalizer,mapping,overwrite', task_types='data-mapping,debugging', entities='RoutingPayloadBuilder,StatusNormalizer', evidence='src/main/java/com/acme/order/RoutingPayloadBuilder.java,src/main/java/com/acme/order/StatusNormalizer.java').stdout)
check('related not rejected', 'rejected' not in learn(type='trap', repo_id='order-routing-demo', scope='repo', namespace='implementation.data-mapping', claim='Payload builders can hide later transformations outside the builder path', why='Future investigations should verify whether post-builder services transform payload values before dispatch', confidence='likely', tags='payload,builder,transform', task_types='data-mapping', entities='RoutingPayloadBuilder', evidence='src/main/java/com/acme/order/RoutingPayloadBuilder.java').stdout)

small=mem(['recall','--repo-id','order-routing-demo','--query','persisted retry scheduling','--budget','small']).stdout
deep=mem(['recall','--repo-id','order-routing-demo','--query','persisted retry scheduling','--budget','deep']).stdout
check('small excludes held', held_missing not in small and workspace not in small, small)
check('deep includes held', held_missing in deep or workspace in deep, deep)
check('workspace promote gate', mem(['promote','--id',workspace]).returncode!=0)
check('workspace promote approved', mem(['promote','--id',workspace,'--approve-workspace']).returncode==0)
check('global promote gate', mem(['promote','--id',globalid]).returncode!=0)
check('global promote approved', mem(['promote','--id',globalid,'--approve-global']).returncode==0)
check('quiet succeeds', mem(['quiet','--id',mem1]).returncode==0)
check('small excludes quiet', mem(['recall','--repo-id','order-routing-demo','--query','status normalizer mapping','--budget','small']).stdout.find(mem1)==-1)
check('deep includes quiet', mem(['recall','--repo-id','order-routing-demo','--query','status normalizer mapping','--budget','deep']).stdout.find(mem1)!=-1)

r=learn(type='validation', repo_id='order-routing-demo', scope='repo', namespace='testing.validation', claim='Order routing component tests verify serialized routing payload behavior better than isolated unit tests', why='Future payload changes should update the component test fixture to validate end-to-end routing behavior', confidence='confirmed', tags='component,test,payload,serialization', task_types='testing,validation', entities='OrderRoutingComponentTest', evidence='src/test/java/com/acme/order/OrderRoutingComponentTest.java,src/test/resources/features/order-routing.feature')
valid=get_id('promoted',r.stdout)
check('validation promote', bool(valid) or 'merged' in r.stdout, r.stdout)
if valid:
    out0=mem(['recall','--repo-id','order-routing-demo','--query','component payload validation','--budget','small','--min-score','0']).stdout
    mem(['feedback','--id',valid,'--signal','irrelevant','--query','component payload validation'])
    out1=mem(['recall','--repo-id','order-routing-demo','--query','component payload validation','--budget','small','--min-score','0']).stdout
    def score(out, id):
        m=re.search(r'Score: ([0-9.-]+) \| id='+re.escape(id), out); return float(m.group(1)) if m else None
    check('feedback lowers score', score(out0,valid) is not None and score(out1,valid) is not None and score(out1,valid)<score(out0,valid), out0+'\n---\n'+out1)

check('reject promoted', mem(['reject','--id',globalid,'--reason','test']).returncode==0)
check('rejected not recalled', globalid not in mem(['recall','--repo-id','order-routing-demo','--query','current source override conflict','--budget','review','--min-score','0']).stdout)
r=learn(type='lesson', repo_id='order-routing-demo', scope='repo', namespace='agent.workflow', claim='Current code should be verified before relying on any recalled repo memory', why='This keeps memory as an investigation aid rather than a source of truth for implementation work', confidence='confirmed', tags='memory,verification', task_types='agent', evidence='note:framework invariant')
newid=get_id('promoted',r.stdout)
if valid and newid:
    check('supersede succeeds', mem(['supersede','--id',valid,'--by',newid]).returncode==0)
    check('superseded not recalled', valid not in mem(['recall','--repo-id','order-routing-demo','--query','component payload validation','--budget','review','--min-score','0']).stdout)

check('verify succeeds', mem(['verify','--id',workspace]).returncode==0)
(BASE/'UNRELATED.md').write_text('unrelated'); run('git add UNRELATED.md && git commit -q -m unrelated', checkrc=True)
check('unrelated commit not stale', 'evidence changed since verification' not in mem(['recall','--repo-id','order-routing-demo','--query','persisted retry state scheduling','--budget','deep','--min-score','0']).stdout)
(BASE/'src/main/java/com/acme/order/RetryScheduler.java').write_text('class RetryScheduler { RetryStateRepository repo; int changed; }'); run('git add src/main/java/com/acme/order/RetryScheduler.java && git commit -q -m change-evidence', checkrc=True)
check('evidence change stale', 'evidence changed since verification' in mem(['recall','--repo-id','order-routing-demo','--query','persisted retry state scheduling','--budget','deep','--min-score','0']).stdout)
check('namespace filter excludes', 'Status fields may be normalized' not in mem(['recall','--repo-id','order-routing-demo','--query','status normalizer mapping','--budget','deep','--namespace','testing.validation','--min-score','0']).stdout)
r=learn(type='pattern', repo_id='other-service', scope='repo', namespace='implementation.data-mapping', claim='Other service maps shipment status through a generated mapper before dispatch', why='This should not be recalled by current repo unless other-repo recall is explicitly enabled', confidence='likely', tags='shipment,status,mapper', task_types='data-mapping', entities='ShipmentMapper', evidence='note:other repo evidence')
other=get_id('promoted',r.stdout)
check('other excluded default', not other or other not in mem(['recall','--repo-id','order-routing-demo','--query','shipment status generated mapper','--budget','deep','--min-score','0']).stdout)
check('other included requested', not other or other in mem(['recall','--repo-id','order-routing-demo','--query','shipment status generated mapper','--budget','deep','--min-score','0','--include-other-repos']).stdout)
review=mem(['review']).stdout
check('review runs', '# Brain Review' in review)
check('stats runs', 'Status counts' in mem(['stats']).stdout)
check('branch summary runs', 'Brain Branch Summary' in mem(['branch-summary']).stdout)
for args,name,payload in [(['hook-session-start'],'hook session',''),(['hook-post-tool-use'],'hook post',json.dumps({'path':'.ai/brain/memories/x.json'})),(['hook-pre-compact'],'hook compact',json.dumps({'transcript':'abc'})),(['hook-pre-tool-use'],'hook pre safe',json.dumps({'path':'src/A.java'}))]:
    r=mem(args,input=payload); 
    try: json.loads(r.stdout); ok=True
    except Exception: ok=False
    check(name+' json', ok and r.returncode==0, r.stdout+r.stderr)
obj=json.loads(mem(['hook-pre-tool-use'],input=json.dumps({'path':'.ai/brain/index/memory.sqlite'})).stdout)
check('deny index edit', obj.get('decision')=='deny', str(obj))
obj=json.loads(mem(['hook-pre-tool-use'],input=json.dumps({'path':'.ai/brain/memories/a.json','content':'password=supersecretvalue'})).stdout)
check('deny secret edit', obj.get('decision')=='deny', str(obj))
(BASE/'.ai/brain/memories/bad.json').write_text('{bad')
r=mem(['rebuild']); check('invalid json skipped', r.returncode==0 and 'Warning: skipping invalid memory' in r.stderr, r.stdout+r.stderr); (BASE/'.ai/brain/memories/bad.json').unlink()
(BASE/'.ai/brain/index/memory.sqlite').write_text('not sqlite')
r=mem(['recall','--repo-id','order-routing-demo','--query','status normalizer mapping','--budget','deep','--min-score','0'])
check('corrupt sqlite fallback', r.returncode==0 and 'Warning: SQLite recall failed' in r.stderr and '# Brain Recall' in r.stdout, r.stdout+r.stderr)
mem(['rebuild'])
check('tiny max chars no crash', mem(['recall','--repo-id','order-routing-demo','--query','status normalizer mapping','--budget','deep','--max-chars','10','--min-score','0']).returncode==0)
check('command evidence accepted', 'promoted' in learn(type='validation', repo_id='order-routing-demo', scope='repo', namespace='testing.validation', claim='A documented command can be used as evidence when no single source file owns validation behavior', why='Some validation memories are supported by command output rather than a durable file path', confidence='likely', tags='command,evidence,validation', task_types='testing', evidence='command:mvn test').stdout)
outside='/tmp/outside-evidence-file.txt'; Path(outside).write_text('outside')
r=learn(type='pattern', repo_id='order-routing-demo', scope='repo', namespace='implementation.patterns', claim='Outside evidence path should not be treated as safe repository evidence', why='Memory evidence should be repo-relative, command, commit, or note evidence so recall remains portable', confidence='likely', tags='evidence,path', task_types='implementation', evidence=outside)
check('outside abs evidence held', 'promoted' not in r.stdout and 'outside_repo_evidence' in r.stdout, r.stdout)
r=learn(type='pattern', repo_id='order-routing-demo', scope='repo', namespace='implementation.patterns', claim='Missing file evidence should hold the memory proposal until verified', why='A repo scoped memory should not be accepted if the referenced evidence file does not exist', confidence='likely', tags='evidence,missing', task_types='implementation', evidence='src/nope/Missing.java')
check('missing file evidence held', 'held' in r.stdout and 'missing_evidence_path' in r.stdout, r.stdout)

# v5 hardening additions
r=learn(type='pattern', repo_id='order-routing-demo', scope='repo', namespace='Implementation Patterns', claim='Bad namespace formats should be held instead of polluting recall buckets', why='Namespaces need stable lowercase dotted identifiers so recall filters and stats stay predictable', confidence='likely', tags='namespace,format', task_types='implementation', evidence='src/main/java/com/acme/order/RoutingPayloadBuilder.java')
check('invalid namespace held', 'held' in r.stdout and 'invalid_namespace_format' in r.stdout, r.stdout)
r=learn(type='pattern', repo_id='order-routing-demo', scope='repo', namespace='implementation.patterns', claim='All routing payload changes should be reviewed through the component validation path', why='Broad claims with likely confidence should be held unless confirmed so they do not bias too many future tasks', confidence='likely', tags='broad,validation', task_types='implementation', evidence='src/main/java/com/acme/order/RoutingPayloadBuilder.java')
check('broad likely repo held', 'held' in r.stdout and 'broad_claim_requires_confirmed_confidence' in r.stdout, r.stdout)
r=learn(type='pattern', repo_id='order-routing-demo', scope='repo', namespace='implementation.patterns', claim='Commit evidence should hold when the referenced commit does not exist in this repository', why='Invalid commit evidence cannot support a memory proposal and must not be auto promoted', confidence='likely', tags='commit,evidence', task_types='implementation', evidence='commit:deadbeefdeadbeefdeadbeefdeadbeefdeadbeef')
check('invalid commit evidence held', 'held' in r.stdout and 'invalid_commit_evidence' in r.stdout, r.stdout)
# absolute evidence inside repo should be normalized to repo-relative
abs_ev=str((BASE/'src/main/java/com/acme/order/StatusNormalizer.java').resolve())
r=learn(type='pattern', repo_id='order-routing-demo', scope='repo', namespace='implementation.data-mapping', claim='Absolute evidence inside the repository should be normalized before storing memory', why='Memory evidence should remain portable across clones while still accepting agent supplied absolute paths inside the repo', confidence='confirmed', tags='evidence,normalization,path', task_types='implementation', evidence=abs_ev)
check('absolute inside repo accepted', 'promoted' in r.stdout or 'merged' in r.stdout, r.stdout)
found_abs=False
for pth in (BASE/'.ai/brain/memories').glob('*.json'):
    txt=pth.read_text()
    if 'Absolute evidence inside the repository' in txt:
        found_abs=abs_ev in txt
check('absolute evidence normalized', not found_abs, 'absolute path leaked into memory file')
# hook local logs must redact secret-like payloads
payload=json.dumps({'tool':'edit','content':'password=supersecretvalue token=abcd1234567890'})
mem(['hook-post-tool-use'], input=payload)
logs=''.join(p.read_text() for p in (BASE/'.ai/brain/local').glob('*.jsonl'))
check('hook local log redacts secrets', 'supersecretvalue' not in logs and 'abcd1234567890' not in logs and '[REDACTED]' in logs, logs)
# repeated identical claims in same second should not collide ids/files
r1=learn(type='trap', repo_id='order-routing-demo', scope='repo', namespace='debugging.known-traps', claim='Repeated identical memory claims should still receive unique identifiers when learned quickly', why='Agents can retry the same memory proposal and storage should not collide or overwrite existing files', confidence='likely', tags='id,collision', task_types='debugging', evidence='note:first')
r2=learn(type='trap', repo_id='order-routing-demo', scope='repo', namespace='debugging.known-traps', claim='Repeated identical memory claims should still receive unique identifiers when learned quickly', why='Agents can retry the same memory proposal and storage should not collide or overwrite existing files', confidence='likely', tags='id,collision', task_types='debugging', evidence='note:second')
check('same second ids safe', get_id('promoted', r1.stdout) != get_id('merged', r2.stdout), r1.stdout + r2.stdout)

# v7 prime-session docs and CLI contract
instr=(BASE/'.github/copilot-instructions.md').read_text().lower()
skill=(BASE/'.github/skills/brain-memory/SKILL.md').read_text().lower()
readme=(BASE/'.ai/brain/README.md').read_text().lower()
check('docs preserve recall flagship hierarchy', 'task-specific brain recall is the flagship' in instr and 'prime-session does not replace task-specific recall' in skill and 'task recall is the primary feature' in readme, instr+skill+readme)
check('prime help available', 'prime-session' in mem(['--help']).stdout)

# invalid type/scope are enforced by argparse choices
check('invalid type exits nonzero', mem(['learn','--type','bad','--claim','This invalid type should fail before processing','--why','The command choices should prevent unsupported memory types']).returncode!=0)
print('\nRESULT',passed,'passed',failed,'failed','elapsed',round(time.time()-start,2),'temp_repo',BASE, flush=True)
if failures:
    for n,d in failures:
        print('\nFAIL',n,'\n',d[:3000])
    sys.exit(1)
