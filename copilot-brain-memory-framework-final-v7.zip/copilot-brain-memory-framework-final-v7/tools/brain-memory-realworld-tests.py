#!/usr/bin/env python3
import json, os, shutil, subprocess, sys, tempfile, time
from pathlib import Path

SRC=Path(__file__).resolve().parents[1]
PY=sys.executable
SCRIPT='.github/skills/brain-memory/memory.py'
PY_CMD=[PY,'-S']
passed=failed=0; failures=[]

def check(name, cond, detail=''):
    global passed, failed
    if cond:
        passed+=1; print('PASS', name, flush=True)
    else:
        failed+=1; failures.append((name, detail)); print('FAIL', name, detail[:1000], flush=True)

def run(cwd,args,input=None,timeout=30,shell=False):
    return subprocess.run(args if not isinstance(args,str) else args, cwd=cwd, text=True, capture_output=True, input=input, timeout=timeout, shell=isinstance(args,str) or shell)

def mem(cwd,args,input=None,timeout=30):
    return run(cwd,PY_CMD+[str(SRC / SCRIPT)]+args,input=input,timeout=timeout)

def copy_repo(name='repo'):
    base=Path(tempfile.mkdtemp(prefix=f'brain-real-{name}-'))
    shutil.copytree(SRC, base, dirs_exist_ok=True)
    return base

def init_git(base):
    run(base,'git init -q',timeout=10)
    run(base,'git config user.email test@example.com && git config user.name Tester',timeout=10)
    run(base,'git add . && git commit -q -m initial',timeout=20)

def learn(base,**kw):
    args=['learn']
    for k,v in kw.items():
        flag='--'+k.replace('_','-')
        if v is True or v == '':
            args.append(flag)
        else:
            args += [flag, str(v)]
    return mem(base,args,timeout=30)

# 1. No git repo should not fail; it should use unknown commit and repo folder id.
base=copy_repo('nogit')
(base/'src').mkdir(exist_ok=True)
(base/'src/A.java').write_text('class A {}')
r=mem(base,['init'])
check('no-git init works', r.returncode==0, r.stdout+r.stderr)
prime_empty=mem(base,['prime-session']).stdout
check('prime session empty works', 'No active repo baseline memories found yet' in prime_empty and 'task-specific recall' in prime_empty.lower(), prime_empty)
r=learn(base,type='pattern',scope='repo',namespace='implementation.patterns',claim='No git repositories can still store repo scoped memories with file evidence',why='Some local scratch projects may not have git initialized but memory should still work with unknown commit metadata',confidence='likely',tags='nogit,evidence',task_types='implementation',evidence='src/A.java')
check('no-git learn works', r.returncode==0 and ('promoted' in r.stdout), r.stdout+r.stderr)

# 2. Running from subdirectory should find repo root and write to root .ai.
base=copy_repo('subdir')
(base/'module/src').mkdir(parents=True,exist_ok=True)
(base/'module/src/B.java').write_text('class B {}')
init_git(base)
sub=base/'module/src'
r=mem(sub,['init'])
check('subdir init root detection', r.returncode==0 and (base/'.ai/brain/index/memory.sqlite').exists(), r.stdout+r.stderr)
r=learn(sub,type='pattern',repo_id='subdir-demo',scope='repo',namespace='implementation.patterns',claim='Commands run from nested source folders should still write memory at the repository root',why='Copilot tools may execute commands from subdirectories and the memory system must remain repo-rooted',confidence='likely',tags='root,subdir',task_types='implementation',evidence='module/src/B.java')
check('subdir learn writes root', 'promoted' in r.stdout and len(list((base/'.ai/brain/memories').glob('*.json')))>0, r.stdout)

# 3. Unicode/newlines/quotes should serialize safely and recall.
base=copy_repo('unicode')
(base/'src').mkdir(exist_ok=True); (base/'src/C.java').write_text('class C {}')
init_git(base); mem(base,['init'])
claim='Unicode claims with quotes “status” and newline-sensitive details should remain valid JSON memory records'
r=learn(base,type='lesson',repo_id='unicode-demo',scope='repo',namespace='debugging.investigation',claim=claim,why='Agents may quote compiler messages or use unicode punctuation and memory storage should not corrupt JSON files',confidence='likely',tags='unicode,json,quotes',task_types='debugging',evidence='src/C.java')
check('unicode learn works', 'promoted' in r.stdout, r.stdout+r.stderr)
r=mem(base,['recall','--repo-id','unicode-demo','--query','unicode quotes status json','--budget','small'])
check('unicode recall works', 'Unicode claims' in r.stdout, r.stdout+r.stderr)
prime_unicode=mem(base,['prime-session','--repo-id','unicode-demo']).stdout
check('prime session includes active baseline', 'Unicode claims' in prime_unicode and 'Prime-session does not replace recall' in prime_unicode, prime_unicode)

# 4. Commit evidence HEAD and short hash should validate; bogus should hold (covered in regression but here real git).
base=copy_repo('commit')
(base/'src').mkdir(exist_ok=True); (base/'src/D.java').write_text('class D {}')
init_git(base)
head=run(base,'git rev-parse --short HEAD').stdout.strip()
mem(base,['init'])
r=learn(base,type='validation',repo_id='commit-demo',scope='repo',namespace='testing.validation',claim='Valid commit evidence should be accepted when it points to an existing repository commit',why='Some learnings are supported by a reviewed commit instead of a single source file',confidence='confirmed',tags='commit,evidence',task_types='testing',evidence=f'commit:{head}')
check('valid commit evidence accepted', 'promoted' in r.stdout, r.stdout+r.stderr)

# 5. Performance with 120 memories should stay reasonable with python -S and SQLite recall.
base=copy_repo('perf')
(base/'src').mkdir(exist_ok=True); (base/'src/E.java').write_text('class E {}')
for j in range(60): (base/f'src/E{j}.java').write_text(f'class E{j} {{}}')
init_git(base); mem(base,['init'])
start=time.time()
for i in range(60):
    ns='implementation.patterns' if i%2 else 'debugging.known-traps'
    claim=f'Performance memory {i} unique topic uniqtoken{i} records routing behavior category {i%7} for retrieval testing without excessive delay'
    why=f'This synthetic memory helps verify recall and indexing scale with many small memory records number {i} and uniqtoken{i}'
    res=learn(base,type='pattern',repo_id='perf-demo',scope='repo',namespace=ns,claim=claim,why=why,confidence='likely',tags=f'perf,category{i%7},routing,uniqtoken{i}',task_types='debugging,implementation',evidence=f'src/E{i}.java',entities=f'PerfEntity{i}',defer_rebuild='')
    if res.returncode!=0:
        break
mem(base,['rebuild'])
learn_elapsed=time.time()-start
start=time.time(); r=mem(base,['recall','--repo-id','perf-demo','--query','routing category 3 retrieval testing','--budget','small'],timeout=20); recall_elapsed=time.time()-start
check('bulk learn completed', len(list((base/'.ai/brain/memories').glob('*.json'))) >= 45, f'learn_elapsed={learn_elapsed} count={len(list((base/'.ai/brain/memories').glob('*.json')))}')
check('bulk recall fast enough', r.returncode==0 and recall_elapsed < 3.0, f'elapsed={recall_elapsed}\n{r.stdout}\n{r.stderr}')

# 6. Prompt/skill docs should not use project-specific default namespaces from prior discussion.
skill=(SRC/'.github/skills/brain-memory/SKILL.md').read_text().lower()
check('skill docs project agnostic', all(x not in skill for x in ['blaze', 'vendor-dispatch', 'kafka']) , 'found project-specific term in skill')

# 7. Script-only install should still initialize with useful default task expansions.
base=Path(tempfile.mkdtemp(prefix='brain-real-script-only-'))
(base/'.github/skills/brain-memory').mkdir(parents=True, exist_ok=True)
shutil.copy2(SRC/SCRIPT, base/SCRIPT)
(base/'src').mkdir(exist_ok=True); (base/'src/Z.java').write_text('class Z {}')
r=run(base,[PY,'-S',SCRIPT,'init'])
created_cfg=json.loads((base/'.ai/brain/config.json').read_text())
check('script-only init has rationale defaults', r.returncode==0 and 'rationale' in created_cfg.get('task_expansions',{}) and 'implementation.rationale' in created_cfg.get('generic_namespaces',[]), r.stdout+r.stderr+str(created_cfg.get('task_expansions')))
check('script-only init has prime session defaults', 'prime_session' in created_cfg and 'architecture.flow' in created_cfg.get('prime_session',{}).get('preferred_namespaces',[]), str(created_cfg.get('prime_session')))
check('script-only prime command works', 'Brain Prime Session' in run(base,[PY,'-S',SCRIPT,'prime-session']).stdout)

# 8. Hook pre-compact redacts local checkpoint too.
base=copy_repo('hooksanitize')
init_git(base); mem(base,['init'])
payload=json.dumps({'transcript':'client_secret=abcdefghijklmnop and normal text'})
r=mem(base,['hook-pre-compact'],input=payload)
text=''.join(p.read_text() for p in (base/'.ai/brain/local/pre-compact-checkpoints').glob('*.json'))
check('pre-compact redacts secrets', 'abcdefghijklmnop' not in text and '[REDACTED]' in text, text)

print('\nRESULT',passed,'passed',failed,'failed')
if failures:
    for n,d in failures:
        print('\nFAIL',n,'\n',str(d)[:3000])
    sys.exit(1)
