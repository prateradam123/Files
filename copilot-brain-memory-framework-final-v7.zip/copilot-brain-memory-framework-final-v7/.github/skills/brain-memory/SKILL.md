---
name: brain-memory
description: Agent-agnostic repo memory skill for fast recall and low-friction learning of durable lessons, patterns, traps, and validation knowledge. Use before non-trivial engineering work and after meaningful findings.
---

# Brain Memory Skill

This skill provides a lightweight repo-local memory layer.

A key use case is code archaeology: helping the agent understand why code, configuration, tests, workflows, or design choices exist before assuming intent or simplifying behavior.

The memory system is not a documentation system and not a source of truth. It is a recall assist for reusable lessons, implementation patterns, known traps, and validation knowledge.

Task-specific recall is the flagship feature. Prime-session is a supporting baseline-orientation feature built from memories; it must never be treated as a replacement for task-specific recall.

Use memory as a hint. Verify against current source code. Current code wins.

## Storage model

Memory source files live under `.ai/brain`:

```text
.ai/brain/
  config.json
  memories/     # active, quiet, or superseded memories
  held/         # proposed memories needing review
  rejected/     # rejected proposals retained for audit/dedupe
  feedback/     # recall feedback signals
  index/        # generated SQLite index, ignored by git
  local/        # local/session files, ignored by git
```

The SQLite index is generated. Do not edit it and do not commit it.

Source-of-truth memory records are one JSON file per memory/proposal. This avoids merge conflicts better than a shared JSONL file.

## Memory identity

Every memory proposal should include:

- `repo_id`: where the memory came from
- `scope`: where the memory is safe to reuse
- `namespace`: generic topic area
- `type`: lesson, pattern, trap, or validation

Use `repo_id` for repository identity. Do not cram repo names into `namespace`.

Recommended scopes:

- `repo`: safe only in the current repo by default
- `workspace`: potentially useful across related repos/services in the same system or domain
- `global`: broadly useful agent or engineering behavior

Scope promotion rule:

- `repo` memories may be auto-promoted when narrow, evidence-backed, non-duplicate, and non-contradictory.
- `workspace` memories are held by default unless explicitly approved.
- `global` memories are always held until explicitly approved.

Recommended generic namespaces:

```text
architecture.flow
architecture.boundaries
architecture.dependencies
architecture.decisions

implementation.patterns
implementation.error-handling
implementation.logging
implementation.configuration
implementation.data-mapping
implementation.rationale

integration.messaging
integration.http
integration.database
integration.external-services

testing.unit
testing.integration
testing.component
testing.fixtures
testing.validation

debugging.symptoms
debugging.investigation
debugging.known-traps
debugging.code-archaeology

data.modeling
data.persistence
data.serialization
data.lineage

build.dependencies
build.ci
build.local-dev

operations.monitoring
operations.alerting
operations.runtime

security.auth
security.permissions
security.data-safety

agent.behavior
agent.workflow
agent.validation
```

Repo-specific detail belongs in `tags`, `entities`, `evidence`, `repo_id`, and the claim text.

## Memory schema

A complete memory record uses this shape:

```json
{
  "id": "mem-...",
  "repo_id": "current-repo",
  "scope": "repo",
  "namespace": "implementation.data-mapping",
  "type": "trap",
  "status": "active",
  "claim": "Status fields may be normalized after initial DTO mapping.",
  "why": "Future mapping investigations should check post-mapping normalization before assuming the mapped value is final.",
  "applicability": "Use when tracing outbound payload or DTO field values.",
  "not_applicable_when": "Do not assume this applies to inbound validation unless verified.",
  "verification": "Inspect the mapper and any post-mapping normalizer before relying on this memory.",
  "confidence": "likely",
  "tags": ["status", "normalizer", "mapping", "overwrite"],
  "task_types": ["debugging", "implementation"],
  "entities": ["PayloadBuilder", "StatusNormalizer"],
  "evidence": ["src/main/java/.../PayloadBuilder.java"],
  "last_verified_at": "2026-06-19T12:00:00Z",
  "last_verified_commit": "abc1234"
}
```

Required for proposals:

- type
- repo_id
- scope
- namespace
- claim
- why
- evidence, unless the memory is a safe global agent-behavior rule


## Evidence rules

Evidence should be portable and reviewable. Accepted evidence forms:

- repo-relative file paths that currently exist
- absolute paths only when they resolve inside the current repo
- `commit:<sha>`
- `command:<command>`
- `note:<short note>`

Repo-scoped memories with missing or outside-repo file evidence are held, not auto-promoted. This keeps recalled memories portable across branches and machines.

Strongly recommended:

- applicability
- not_applicable_when
- verification
- tags
- task_types
- entities

## Status values

- `active`: normal recall
- `quiet`: stored but only returned in deep/review recall
- `held`: needs review or explicit approval
- `rejected`: not used for normal recall
- `superseded`: replaced by newer memory

## Core commands

Run from repository root when possible. When commands may run from a subdirectory, use the robust form:

```bash
python -S "$(git rev-parse --show-toplevel)/.github/skills/brain-memory/memory.py" recall --query "<task>" --budget small
```


Initialize:

```bash
python -S .github/skills/brain-memory/memory.py init
```

Rebuild generated index:

```bash
python -S .github/skills/brain-memory/memory.py rebuild
```

Prime a fresh agent/session with compact baseline repo context:

```bash
python -S .github/skills/brain-memory/memory.py prime-session
```

Recall task-specific memory:

```bash
python -S .github/skills/brain-memory/memory.py recall \
  --query "<task summary>" \
  --budget small
```

Submit a learning proposal:

```bash
python -S .github/skills/brain-memory/memory.py learn \
  --type trap \
  --repo-id "<repo-id>" \
  --scope repo \
  --namespace "implementation.data-mapping" \
  --claim "<short durable claim>" \
  --why "<why this helps future work>" \
  --confidence likely \
  --tags "tag1,tag2" \
  --task-types "debugging,implementation" \
  --entities "ClassA,ClassB" \
  --evidence "path/to/file1,path/to/file2"
```

Review memory health:

```bash
python -S .github/skills/brain-memory/memory.py stats
python -S .github/skills/brain-memory/memory.py review
```

Promote held memory:

```bash
python -S .github/skills/brain-memory/memory.py promote --id <memory-id>
```

Promote workspace/global memory only with explicit approval:

```bash
python -S .github/skills/brain-memory/memory.py promote --id <memory-id> --approve-workspace
python -S .github/skills/brain-memory/memory.py promote --id <memory-id> --approve-global
```

Reject held memory:

```bash
python -S .github/skills/brain-memory/memory.py reject --id <memory-id> --reason "<reason>"
```

Mark recall feedback:

```bash
python -S .github/skills/brain-memory/memory.py feedback \
  --id <memory-id> \
  --signal irrelevant \
  --query "<query that retrieved it>"
```

## Prime-session protocol

Prime-session is a supporting feature for fresh agent contexts. It provides a compact baseline working model of the repo from high-value active memories.

Use it once near the beginning of a meaningful new agent/session:

```bash
python -S .github/skills/brain-memory/memory.py prime-session
```

Prime-session should answer broad orientation questions:

- what kind of repo this is
- important architecture or flow guidance
- core invariants and rationale
- validation/test paths
- known traps and code-archaeology warnings
- important files, entities, or patterns surfaced by memories

Prime-session is not task-specific. It should be compact, broad, and stable. It should not load all memories.

Critical rule:

> Prime-session does not replace task-specific recall.

After the concrete task is known, run targeted task recall for non-trivial repo work even if prime-session was already run. Prime tells the agent where it is. Recall tells the agent what prior repo knowledge matters for the actual work.

Skip prime-session for tiny mechanical edits. Skip task recall only for clearly trivial mechanical edits where prior repo knowledge would not affect the approach.

## Recall protocol

Task-specific recall is the primary working-memory mechanism of the brain framework. Do not treat recall as second-class because prime-session was run.

Before non-trivial work, after the task is known:

1. Summarize the task into a compact query.
2. Detect likely task type when possible.
3. Run recall with a small budget by default.
4. Load only compact returned summaries.
5. State which memories were used.
6. Verify against current code.
7. If recall is weak for high-risk work, run broader recall.

Default:

```bash
python -S .github/skills/brain-memory/memory.py recall --query "<task>" --budget small
```

High-risk tasks should use `medium` or `deep`:

- complex debugging
- data/model mapping
- large refactors
- integration/retry/error-handling changes
- rules or decision logic changes
- important validation/test work

Recall budgets:

- `small`: fast default, usually 3-5 compact memories
- `medium`: broader, usually 6-8 compact memories
- `deep`: highest recall, usually 10-12 compact memories plus quiet/held warnings

If the current user prompt is a direct continuation of the same task and previous recall is still relevant, reuse prior recall context instead of rerunning recall.

If memory recall fails or returns weak results, continue the task normally and mention the limitation briefly.

### Rationale and code-archaeology recall

When investigating intent or rationale — for example, "why is this here?", "why is this done this way?", "why does this repo avoid X?", "why did prior work choose Y?", or "can this workaround be removed?" — run recall before forming a conclusion.

Use queries that include the behavior, files, entities, and suspected decision area. Prefer `--task-type rationale` for explicit why/intent questions and `--task-type refactoring` when removing, simplifying, replacing, or modernizing non-obvious code.

Treat recalled rationale as a hypothesis. Verify it against current code, tests, commits, and evidence before explaining the reason or changing behavior. Current code still wins.

Before deleting or simplifying unusual retries, compatibility code, feature flags, tests, mappings, operational safeguards, or workarounds, recall memory and look for prior constraints, regressions, hidden consumers, validation requirements, or reasons not to simplify.

## Retrieval quality requirements

Do not rely only on exact keyword search.

Recall should consider:

- query text
- task type
- expanded terms
- tags
- entities
- file paths
- repo_id
- scope
- namespace
- confidence
- status
- freshness/stale warnings
- prior feedback

Default ranking should favor:

1. current repo active memories
2. current repo quiet memories only in deep/review mode
3. workspace memories when relevant
4. global memories when relevant
5. other-repo memories only when explicitly enabled

Memory should be injected compactly. Do not load full evidence/history unless needed.

## Learning protocol

At the end of meaningful work, ask:

> Did we learn a durable repo-specific lesson, pattern, trap, or validation insight that should help future work?

If yes, submit a structured proposal with `memory.py learn`.

The agent performs semantic extraction. The Python script performs deterministic intake, validation, dedupe, routing, stale checks, and indexing.

The script does not magically know truth. The agent must provide a specific, evidence-backed proposal.

`memory.py learn` routes proposals to:

- `active`: accepted memory
- `merged`: duplicate/reinforcement of existing memory
- `held`: potentially useful but ambiguous, broad, risky, workspace/global, contradictory, or weakly supported
- `rejected`: generic, unsupported, too temporary, obvious, or noisy

Do not require the user to manually curate every candidate.

Only held memories should occasionally need review.

## What counts as memory-worthy

Good memories are:

- specific
- durable
- reusable
- repo/project/domain/workflow specific
- evidence-backed
- compact
- safe to recall later

Good types:

- `lesson`: something learned that changes future approach
- `pattern`: established implementation/validation/project pattern
- `trap`: known gotcha, false assumption, or thing not to do
- `validation`: test, fixture, scenario, command, or proof strategy that matters

Rationale memories are usually `lesson`, `pattern`, or `trap` records in namespaces such as `architecture.decisions`, `implementation.rationale`, `debugging.investigation`, or `debugging.code-archaeology`. They should explain the decision or constraint and how to verify whether it still applies.

Do not save:

- generic coding advice
- secrets or sensitive data
- temporary debugging details
- obvious facts
- unsupported speculation
- one-off implementation minutiae
- broad claims beyond evidence
- private incident/customer/production details

## Stale evidence

A memory can become stale. Do not delete it automatically.

If evidence files are missing or changed since `last_verified_commit`, recall should show a stale warning.

Current code still wins.

## Hooks

Hooks are optional. The framework must work without them.

Where supported, hooks may be used for deterministic maintenance and guardrails:

- `sessionStart`: initialize/rebuild index and inject tiny “brain available” context
- `postToolUse`: record changed files and mark stale evidence
- `preCompact`: save local session checkpoint
- `preToolUse`: protect generated index files and block unsafe memory writes

Hooks should not perform semantic learning. The agent should do that through this skill.

## Bulk learning

For `/brain-prime` or other bulk memory creation, use `--defer-rebuild` on each `learn` call, then run one final `rebuild`. Normal single-memory learning should rebuild immediately.

```bash
python -S .github/skills/brain-memory/memory.py learn ... --defer-rebuild
python -S .github/skills/brain-memory/memory.py rebuild
```
