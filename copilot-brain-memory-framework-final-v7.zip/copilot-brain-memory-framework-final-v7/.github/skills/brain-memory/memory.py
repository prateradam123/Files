#!/usr/bin/env python3
"""
Brain Memory CLI

Repo-local memory assist for Copilot agents.

Design:
- Agent proposes semantic learnings.
- This script performs deterministic intake, validation, dedupe, routing, stale checks, and indexing.
- Memory files are JSON source of truth.
- SQLite FTS is generated recall index.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import uuid
import io
import json
import os
import re
import shutil
import sqlite3
import contextlib
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = 1

DEFAULT_CONFIG: Dict[str, Any] = {
    "version": 1,
    "default_scope": "repo",
    "default_namespace": "implementation.patterns",
    "allowed_scopes": ["repo", "workspace", "global"],
    "allowed_types": ["lesson", "pattern", "trap", "validation"],
    "allowed_confidence": ["speculative", "likely", "confirmed"],
    "allowed_statuses": ["active", "quiet", "held", "rejected", "superseded"],
    "budgets": {
        "small": {"limit": 5, "max_chars": 2500, "include_quiet": False, "include_held": False, "min_score": 7.0},
        "medium": {"limit": 8, "max_chars": 4500, "include_quiet": False, "include_held": False, "min_score": 5.0},
        "deep": {"limit": 12, "max_chars": 7500, "include_quiet": True, "include_held": True, "min_score": 2.0},
        "review": {"limit": 20, "max_chars": 12000, "include_quiet": True, "include_held": True, "min_score": 0.0},
    },
    "prime_session": {
        "limit": 12,
        "max_chars": 5500,
        "min_score": 4.0,
        "preferred_namespaces": [
            "architecture.flow",
            "architecture.boundaries",
            "architecture.dependencies",
            "architecture.decisions",
            "implementation.patterns",
            "implementation.rationale",
            "integration.messaging",
            "integration.http",
            "integration.database",
            "testing.validation",
            "testing.component",
            "debugging.known-traps",
            "debugging.code-archaeology",
            "operations.monitoring",
            "operations.runtime"
        ],
        "preferred_types": ["pattern", "trap", "validation", "lesson"],
        "excluded_statuses": ["held", "rejected", "quiet", "superseded"]
    },
    "generic_namespaces": [
            "architecture.flow",
            "architecture.boundaries",
            "architecture.dependencies",
            "architecture.decisions",
            "implementation.patterns",
            "implementation.error-handling",
            "implementation.logging",
            "implementation.configuration",
            "implementation.data-mapping",
            "implementation.rationale",
            "integration.messaging",
            "integration.http",
            "integration.database",
            "integration.external-services",
            "testing.unit",
            "testing.integration",
            "testing.component",
            "testing.fixtures",
            "testing.validation",
            "debugging.symptoms",
            "debugging.investigation",
            "debugging.known-traps",
            "debugging.code-archaeology",
            "data.modeling",
            "data.persistence",
            "data.serialization",
            "data.lineage",
            "build.dependencies",
            "build.ci",
            "build.local-dev",
            "operations.monitoring",
            "operations.alerting",
            "operations.runtime",
            "security.auth",
            "security.permissions",
            "security.data-safety",
            "agent.behavior",
            "agent.workflow",
            "agent.validation"
    ],
    "task_expansions": {
            "data-mapping": [
                    "mapping",
                    "mapper",
                    "dto",
                    "model",
                    "payload",
                    "field",
                    "serialize",
                    "deserialize",
                    "normalizer",
                    "converter",
                    "adapter",
                    "builder",
                    "parser",
                    "schema",
                    "transform"
            ],
            "testing": [
                    "test",
                    "validation",
                    "fixture",
                    "mock",
                    "stub",
                    "component",
                    "integration",
                    "unit",
                    "coverage",
                    "assertion",
                    "regression"
            ],
            "debugging": [
                    "debug",
                    "failure",
                    "bug",
                    "symptom",
                    "root cause",
                    "logs",
                    "error",
                    "exception",
                    "investigation",
                    "reproduce",
                    "trace"
            ],
            "implementation": [
                    "implement",
                    "pattern",
                    "service",
                    "controller",
                    "repository",
                    "builder",
                    "configuration",
                    "error handling",
                    "logging"
            ],
            "integration": [
                    "integration",
                    "message",
                    "event",
                    "http",
                    "api",
                    "database",
                    "queue",
                    "topic",
                    "client",
                    "external service",
                    "retry"
            ],
            "architecture": [
                    "architecture",
                    "boundary",
                    "flow",
                    "dependency",
                    "module",
                    "layer",
                    "entrypoint",
                    "ownership",
                    "contract"
            ],
            "operations": [
                    "monitoring",
                    "alert",
                    "metric",
                    "splunk",
                    "log",
                    "runtime",
                    "dashboard",
                    "incident",
                    "deployment"
            ],
            "agent": [
                    "agent",
                    "copilot",
                    "workflow",
                    "prompt",
                    "skill",
                    "memory",
                    "recall",
                    "validation"
            ],
            "rationale": [
                    "why",
                    "rationale",
                    "intent",
                    "decision",
                    "chosen",
                    "choice",
                    "reason",
                    "because",
                    "history",
                    "legacy",
                    "tradeoff",
                    "constraint",
                    "workaround",
                    "non-obvious",
                    "not obvious",
                    "done this way",
                    "exists",
                    "avoid",
                    "preserve",
                    "simplify",
                    "remove",
                    "delete",
                    "refactor",
                    "archaeology",
                    "prior decision"
            ],
            "refactoring": [
                    "refactor",
                    "simplify",
                    "remove",
                    "delete",
                    "cleanup",
                    "replace",
                    "modernize",
                    "rewrite",
                    "consolidate",
                    "dead code",
                    "legacy",
                    "workaround",
                    "behavior",
                    "invariant",
                    "compatibility",
                    "migration",
                    "preserve",
                    "risk",
                    "rationale",
                    "why",
                    "tests",
                    "validation"
            ]
    },
    "routing": {
        "auto_promote_repo_scope": True,
        "hold_workspace_scope_by_default": True,
        "hold_global_scope_by_default": True,
        "reject_generic_claims": True,
        "hold_speculative_claims": True,
        "require_evidence_for_repo_memories": True,
        "require_evidence_for_workspace_memories": True,
        "allow_global_without_file_evidence_for_agent_safety_rules": True,
        "duplicate_jaccard_threshold": 0.88,
        "near_duplicate_jaccard_threshold": 0.74,
    },
    "security": {
        "blocked_secret_terms": ["password", "passwd", "secret", "token", "api_key", "apikey", "credential", "private_key", "client_secret", "access_key", "refresh_token"],
        "blocked_sensitive_terms": ["ssn", "social security", "customer data", "production id", "prod incident", "personally identifiable", "pii"],
    },
}

GENERIC_PHRASES = [
    "write clean code",
    "use good error handling",
    "add tests",
    "follow best practices",
    "be careful",
    "make sure it works",
    "use logging",
    "handle errors",
]

STOPWORDS = {
    "the", "a", "an", "and", "or", "but", "of", "to", "in", "on", "for", "with", "by", "from",
    "is", "are", "was", "were", "be", "been", "being", "this", "that", "these", "those", "it", "as",
    "at", "if", "then", "than", "when", "while", "into", "over", "under", "after", "before", "should",
}


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def find_repo_root(start: Optional[Path] = None) -> Path:
    cur = (start or Path.cwd()).resolve()
    for p in [cur] + list(cur.parents):
        if (p / ".git").exists() or (p / ".github").exists() or (p / ".ai").exists():
            return p
    return cur


ROOT = find_repo_root()
BRAIN = ROOT / ".ai" / "brain"
MEMORIES = BRAIN / "memories"
HELD = BRAIN / "held"
REJECTED = BRAIN / "rejected"
FEEDBACK = BRAIN / "feedback"
INDEX = BRAIN / "index"
LOCAL = BRAIN / "local"
CONFIG_PATH = BRAIN / "config.json"
DB_PATH = INDEX / "memory.sqlite"

# Avoid repeated expensive git checks during a single command.
_STALE_CHANGE_CACHE: Dict[Tuple[str, str], List[str]] = {}


def ensure_dirs() -> None:
    for d in [BRAIN, MEMORIES, HELD, REJECTED, FEEDBACK, INDEX, LOCAL]:
        d.mkdir(parents=True, exist_ok=True)
    for d in [MEMORIES, HELD, REJECTED, FEEDBACK]:
        keep = d / ".gitkeep"
        if not keep.exists():
            keep.write_text("", encoding="utf-8")


def read_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(path)


def load_config() -> Dict[str, Any]:
    cfg = json.loads(json.dumps(DEFAULT_CONFIG))
    if CONFIG_PATH.exists():
        try:
            user_cfg = read_json(CONFIG_PATH)
            cfg = deep_merge(cfg, user_cfg)
        except Exception as e:
            print(f"Warning: failed to read config {CONFIG_PATH}: {e}", file=sys.stderr)
    return cfg


def deep_merge(a: Dict[str, Any], b: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(a)
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def run_git(args: List[str]) -> Optional[str]:
    try:
        res = subprocess.run(["git"] + args, cwd=ROOT, text=True, capture_output=True, timeout=5)
        if res.returncode == 0:
            return res.stdout.strip()
    except Exception:
        pass
    return None


def current_commit() -> str:
    return run_git(["rev-parse", "HEAD"]) or "unknown"


def current_branch() -> str:
    return run_git(["rev-parse", "--abbrev-ref", "HEAD"]) or "unknown"


def default_repo_id() -> str:
    remote = run_git(["config", "--get", "remote.origin.url"])
    if remote:
        cleaned = remote.rstrip("/").split("/")[-1]
        if cleaned.endswith(".git"):
            cleaned = cleaned[:-4]
        if cleaned:
            return re.sub(r"[^A-Za-z0-9_.-]+", "-", cleaned)
    return re.sub(r"[^A-Za-z0-9_.-]+", "-", ROOT.name)



def as_list(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x) for x in value if str(x).strip()]
    if isinstance(value, str):
        return [x.strip() for x in value.split(',') if x.strip()]
    return [str(value)]


def split_csv(value: Optional[str]) -> List[str]:
    if not value:
        return []
    return [x.strip() for x in value.split(",") if x.strip()]


def tokenize(text: str) -> List[str]:
    return [
        t.lower()
        for t in re.findall(r"[A-Za-z0-9_.-]+", text or "")
        if len(t) > 2 and t.lower() not in STOPWORDS
    ]


def token_set(text: str) -> set[str]:
    return set(tokenize(text))


def jaccard(a: str, b: str) -> float:
    sa, sb = token_set(a), token_set(b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def slug(s: str, n: int = 48) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "-", s.lower()).strip("-")
    return (s[:n] or "memory").strip("-")


def new_id(prefix: str, claim: str) -> str:
    # Include random entropy to avoid collisions when the same claim is learned
    # more than once inside the same second.
    h = hashlib.sha1((claim + utc_now() + uuid.uuid4().hex).encode("utf-8")).hexdigest()[:8]
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{prefix}-{stamp}-{h}"


def memory_path(memory: Dict[str, Any]) -> Path:
    status = memory.get("status", "active")
    folder = MEMORIES
    if status == "held":
        folder = HELD
    elif status == "rejected":
        folder = REJECTED
    filename = f"{memory['id']}-{slug(memory.get('claim',''))}.json"
    return folder / filename


def all_memory_files(include_rejected: bool = True) -> Iterable[Path]:
    folders = [MEMORIES, HELD]
    if include_rejected:
        folders.append(REJECTED)
    for folder in folders:
        if not folder.exists():
            continue
        yield from sorted(p for p in folder.glob("*.json") if p.is_file())


def load_memories(include_rejected: bool = True) -> List[Tuple[Path, Dict[str, Any]]]:
    items: List[Tuple[Path, Dict[str, Any]]] = []
    for p in all_memory_files(include_rejected=include_rejected):
        try:
            items.append((p, read_json(p)))
        except Exception as e:
            print(f"Warning: skipping invalid memory {p}: {e}", file=sys.stderr)
    return items


def find_memory_by_id(mem_id: str) -> Optional[Tuple[Path, Dict[str, Any]]]:
    for p, m in load_memories(include_rejected=True):
        if m.get("id") == mem_id:
            return p, m
    return None


def evidence_file_paths(memory: Dict[str, Any]) -> List[Path]:
    paths: List[Path] = []
    for ev in as_list(memory.get("evidence")):
        if not isinstance(ev, str):
            continue
        if ev.startswith("commit:") or ev.startswith("command:") or ev.startswith("note:"):
            continue
        p = (ROOT / ev).resolve() if not Path(ev).is_absolute() else Path(ev)
        try:
            p.relative_to(ROOT.resolve())
        except Exception:
            continue
        paths.append(p)
    return paths


def evidence_missing(memory: Dict[str, Any]) -> List[str]:
    missing = []
    for p in evidence_file_paths(memory):
        if not p.exists():
            try:
                missing.append(str(p.relative_to(ROOT)))
            except Exception:
                missing.append(str(p))
    return missing


def validate_evidence_entries(memory: Dict[str, Any]) -> List[str]:
    """Return validation problems for evidence entries.

    Evidence should be portable and reviewable. Accepted forms:
    - repo-relative file paths that currently exist
    - absolute paths only if they resolve inside the repo and exist
    - commit:<sha>, command:<command>, note:<text>

    Missing or outside-repo file paths are held instead of promoted.
    """
    problems: List[str] = []
    for ev in as_list(memory.get("evidence")):
        if not isinstance(ev, str) or not ev.strip():
            continue
        ev = ev.strip()
        if ev.startswith(("commit:", "command:", "note:")):
            continue
        raw = Path(ev)
        resolved = raw.resolve() if raw.is_absolute() else (ROOT / raw).resolve()
        try:
            rel = resolved.relative_to(ROOT.resolve())
        except Exception:
            problems.append(f"outside_repo_evidence:{ev}")
            continue
        if not resolved.exists():
            problems.append(f"missing_evidence_path:{rel}")
    return problems


def valid_namespace(namespace: str) -> bool:
    # Keep namespace generic/topic-oriented and grep/query friendly.
    # Repo/domain specifics belong in repo_id, tags, and entities.
    return bool(re.fullmatch(r"[a-z0-9]+(?:[.-][a-z0-9]+)*(?:\.[a-z0-9]+(?:[.-][a-z0-9]+)*)*", namespace or ""))


def git_commit_exists(commit: str) -> bool:
    if not commit:
        return False
    try:
        res = subprocess.run(["git", "cat-file", "-e", f"{commit}^{{commit}}"], cwd=ROOT, text=True, capture_output=True, timeout=5)
        return res.returncode == 0
    except Exception:
        return False


def normalize_evidence_entries(entries: Any) -> List[str]:
    """Normalize evidence to portable values before storing.

    - Absolute paths inside the repo become repo-relative.
    - command:/note: entries are stripped and preserved.
    - commit: entries are stripped and preserved.
    - Outside paths remain as-is so validation can hold them with a clear reason.
    """
    out: List[str] = []
    for raw_ev in as_list(entries):
        ev = str(raw_ev).strip()
        if not ev:
            continue
        if ev.startswith(("commit:", "command:", "note:")):
            out.append(ev)
            continue
        raw = Path(ev)
        resolved = raw.resolve() if raw.is_absolute() else (ROOT / raw).resolve()
        try:
            rel = resolved.relative_to(ROOT.resolve())
            out.append(str(rel))
        except Exception:
            out.append(ev)
    # Preserve order, remove duplicates.
    seen = set()
    unique = []
    for ev in out:
        if ev not in seen:
            unique.append(ev)
            seen.add(ev)
    return unique


def git_is_ancestor(ancestor: str, descendant: str) -> bool:
    if not ancestor or not descendant or ancestor == "unknown" or descendant == "unknown":
        return False
    try:
        res = subprocess.run(
            ["git", "merge-base", "--is-ancestor", ancestor, descendant],
            cwd=ROOT, text=True, capture_output=True, timeout=5,
        )
        return res.returncode == 0
    except Exception:
        return False


def evidence_changed_since_verify(memory: Dict[str, Any]) -> List[str]:
    last = memory.get("last_verified_commit")
    if not last or last == "unknown":
        return []
    cache_key = (memory.get("id", ""), last)
    if cache_key in _STALE_CHANGE_CACHE:
        return list(_STALE_CHANGE_CACHE[cache_key])
    changed: List[str] = []
    for p in evidence_file_paths(memory):
        if not p.exists():
            continue
        rel = str(p.relative_to(ROOT))
        latest = run_git(["log", "-1", "--format=%H", "--", rel])
        # The evidence is stale only if the latest commit touching the evidence
        # is not an ancestor of the commit where the memory was verified.
        # If the file last changed before verification, it is still fresh.
        if latest and not git_is_ancestor(latest, last):
            changed.append(rel)
    _STALE_CHANGE_CACHE[cache_key] = list(changed)
    return changed


def compact_summary(memory: Dict[str, Any], stale: bool = False, reason: str = "") -> str:
    parts = []
    header = f"[{memory.get('type','memory')}|{memory.get('scope','repo')}|{memory.get('namespace','')}]"
    if memory.get("status") and memory.get("status") != "active":
        header += f" status={memory.get('status')}"
    if stale:
        header += " STALE"
    parts.append(f"- {header} {memory.get('claim','').strip()}")
    if memory.get("applicability"):
        parts.append(f"  Use when: {memory.get('applicability')}")
    if memory.get("verification"):
        parts.append(f"  Verify: {memory.get('verification')}")
    if memory.get("not_applicable_when"):
        parts.append(f"  Do not apply when: {memory.get('not_applicable_when')}")
    ev = as_list(memory.get("evidence"))
    if ev:
        parts.append(f"  Evidence: {', '.join(ev[:3])}{'...' if len(ev) > 3 else ''}")
    if reason:
        parts.append(f"  Retrieved because: {reason}")
    return "\n".join(parts)




def prime_session_score(memory: Dict[str, Any], repo_id: str, cfg: Dict[str, Any]) -> float:
    """Score active repo memories for session-level baseline context.

    Prime-session intentionally differs from task recall:
    - it is broad, stable, and orientation-focused;
    - it is not a substitute for task-specific recall;
    - it should prefer high-confidence repo-scoped memories with reusable guidance.
    """
    ps = cfg.get("prime_session", {}) or {}
    preferred_namespaces = set(ps.get("preferred_namespaces", []) or [])
    preferred_types = set(ps.get("preferred_types", []) or [])
    tags = set(t.lower() for t in as_list(memory.get("tags")))
    tasks = set(t.lower() for t in as_list(memory.get("task_types")))
    namespace = str(memory.get("namespace", ""))
    mtype = str(memory.get("type", ""))

    score = 0.0
    if memory.get("repo_id") == repo_id:
        score += 4.0
    if memory.get("scope") == "repo":
        score += 2.0
    if memory.get("status") == "active":
        score += 2.0
    if memory.get("confidence") == "confirmed":
        score += 1.8
    elif memory.get("confidence") == "likely":
        score += 1.0
    if namespace in preferred_namespaces:
        score += 2.0
    if mtype in preferred_types:
        score += 0.8
    if memory.get("applicability"):
        score += 0.6
    if memory.get("verification"):
        score += 0.6
    if as_list(memory.get("entities")):
        score += 0.5
    if as_list(memory.get("evidence")):
        score += 0.4

    orientation_terms = {
        "architecture", "flow", "invariant", "validation", "component", "test", "trap",
        "rationale", "decision", "boundary", "integration", "retry", "mapping", "monitoring",
        "command", "profile", "entrypoint", "scheduler", "client", "database", "messaging",
    }
    score += 0.35 * min(len((tags | tasks | token_set(namespace.replace('.', ' '))) & orientation_terms), 6)

    # Avoid using memories with weak evidence as session baseline. Targeted recall can still find them.
    if evidence_missing(memory):
        score -= 3.0
    if evidence_changed_since_verify(memory):
        score -= 1.5
    return score


def prime_session_group(memory: Dict[str, Any]) -> str:
    namespace = str(memory.get("namespace", ""))
    mtype = str(memory.get("type", ""))
    tasks = set(t.lower() for t in as_list(memory.get("task_types")))
    tags = set(t.lower() for t in as_list(memory.get("tags")))
    text = " ".join([namespace, mtype, memory.get("claim", ""), " ".join(tags), " ".join(tasks)]).lower()
    if namespace.startswith("testing.") or "test" in text or "validation" in text:
        return "Validation / tests"
    if mtype == "trap" or namespace.startswith("debugging.") or "trap" in text or "gotcha" in text:
        return "Known traps / code archaeology"
    if namespace.startswith("architecture.") or "flow" in text or "boundary" in text or "decision" in text:
        return "Architecture / flow"
    if "rationale" in text or "why" in text or "invariant" in text or "preserve" in text:
        return "Rationale / invariants"
    if namespace.startswith("integration.") or "client" in text or "messaging" in text or "database" in text:
        return "Integration / dependencies"
    if namespace.startswith("operations.") or "metric" in text or "monitoring" in text or "alert" in text:
        return "Operations / observability"
    return "Implementation patterns"


def prime_session_cmd(args: argparse.Namespace) -> None:
    cfg = load_config()
    ensure_index()
    repo_id = args.repo_id or default_repo_id()
    ps = cfg.get("prime_session", {}) or {}
    limit = int(args.limit or ps.get("limit", 12))
    max_chars = int(args.max_chars or ps.get("max_chars", 5500))
    min_score = float(args.min_score if args.min_score is not None else ps.get("min_score", 4.0))
    excluded = set(ps.get("excluded_statuses", ["held", "rejected", "quiet", "superseded"]) or [])

    candidates: List[Tuple[float, Dict[str, Any]]] = []
    for _, m in load_memories(include_rejected=False):
        if m.get("status") in excluded:
            continue
        if m.get("scope") != "repo":
            continue
        if m.get("repo_id") != repo_id:
            continue
        score = prime_session_score(m, repo_id, cfg)
        if score >= min_score:
            candidates.append((score, m))
    candidates.sort(key=lambda x: x[0], reverse=True)

    print("# Brain Prime Session")
    print(f"Repo: {repo_id}")
    print()
    print("Purpose: provide compact baseline repo context for a fresh agent/session.")
    print("Important: task-specific brain recall remains the flagship workflow. Prime-session does not replace recall.")
    print("After the task is known, run targeted recall for non-trivial repo work, then verify against current code.")
    print()

    if not candidates:
        print("No active repo baseline memories found yet.")
        print("Continue normally, use task-specific recall after the task is known, and run /brain-scan after durable discoveries.")
        return

    groups: Dict[str, List[Tuple[float, Dict[str, Any]]]] = {}
    for item in candidates[: max(limit * 2, limit)]:
        groups.setdefault(prime_session_group(item[1]), []).append(item)

    order = [
        "Architecture / flow",
        "Rationale / invariants",
        "Implementation patterns",
        "Integration / dependencies",
        "Validation / tests",
        "Known traps / code archaeology",
        "Operations / observability",
    ]
    used = 0
    emitted = 0
    entities_seen: List[str] = []
    for group in order:
        items = groups.get(group, [])
        if not items:
            continue
        heading = f"## {group}\n"
        if used + len(heading) > max_chars and emitted > 0:
            break
        print(heading, end="")
        used += len(heading)
        for score, m in items:
            stale = bool(evidence_missing(m) or evidence_changed_since_verify(m))
            # Exclude stale baseline content unless explicitly requested; targeted recall can surface stale warnings.
            if stale and not args.include_stale:
                continue
            line = f"- {m.get('claim','').strip()}"
            if m.get("applicability"):
                line += f"\n  Use when: {m.get('applicability')}"
            if m.get("verification"):
                line += f"\n  Verify: {m.get('verification')}"
            ev = as_list(m.get("evidence"))
            if ev:
                line += f"\n  Evidence: {', '.join(ev[:2])}{'...' if len(ev) > 2 else ''}"
            if stale:
                line += "\n  Stale warning: evidence changed or is missing; verify before relying on this."
            line += f"\n  id={m.get('id')} score={score:.2f}\n"
            if used + len(line) > max_chars and emitted > 0:
                break
            print(line)
            used += len(line)
            emitted += 1
            for ent in as_list(m.get("entities")):
                if ent not in entities_seen:
                    entities_seen.append(ent)
            if emitted >= limit:
                break
        print()
        if emitted >= limit or used >= max_chars:
            break

    if entities_seen:
        ents = ", ".join(entities_seen[:12])
        print(f"Important entities surfaced by baseline memories: {ents}{'...' if len(entities_seen) > 12 else ''}")
        print()
    print("Next step: once the concrete task is known, run `memory.py recall --query \"<task>\" --budget small` for task-specific memory.")
    print("Use prime-session as orientation only. Use task recall for the actual work. Current code wins.")

def create_schema(conn: sqlite3.Connection) -> bool:
    conn.execute("DROP TABLE IF EXISTS memories")
    conn.execute("DROP TABLE IF EXISTS feedback")
    conn.execute("DROP TABLE IF EXISTS memory_fts")
    conn.execute(
        """
        CREATE TABLE memories (
          id TEXT PRIMARY KEY,
          path TEXT,
          repo_id TEXT,
          scope TEXT,
          namespace TEXT,
          type TEXT,
          status TEXT,
          confidence TEXT,
          claim TEXT,
          why TEXT,
          applicability TEXT,
          not_applicable_when TEXT,
          verification TEXT,
          tags TEXT,
          task_types TEXT,
          entities TEXT,
          evidence TEXT,
          created_at TEXT,
          updated_at TEXT,
          last_verified_at TEXT,
          last_verified_commit TEXT,
          superseded_by TEXT
        )
        """
    )
    try:
        conn.execute(
            """
            CREATE VIRTUAL TABLE memory_fts USING fts5(
              id UNINDEXED,
              repo_id,
              scope,
              namespace,
              type,
              status,
              claim,
              why,
              applicability,
              verification,
              tags,
              task_types,
              entities,
              evidence
            )
            """
        )
        return True
    except sqlite3.OperationalError:
        return False


def rebuild_index() -> None:
    ensure_dirs()
    if DB_PATH.exists():
        DB_PATH.unlink()
    conn = sqlite3.connect(DB_PATH)
    fts_available = create_schema(conn)
    for path, m in load_memories(include_rejected=True):
        row = {
            "id": m.get("id"),
            "path": str(path.relative_to(ROOT)),
            "repo_id": m.get("repo_id", ""),
            "scope": m.get("scope", ""),
            "namespace": m.get("namespace", ""),
            "type": m.get("type", ""),
            "status": m.get("status", ""),
            "confidence": m.get("confidence", ""),
            "claim": m.get("claim", ""),
            "why": m.get("why", ""),
            "applicability": m.get("applicability", ""),
            "not_applicable_when": m.get("not_applicable_when", ""),
            "verification": m.get("verification", ""),
            "tags": ",".join(m.get("tags", []) or []),
            "task_types": ",".join(m.get("task_types", []) or []),
            "entities": ",".join(m.get("entities", []) or []),
            "evidence": ",".join(m.get("evidence", []) or []),
            "created_at": m.get("created_at", ""),
            "updated_at": m.get("updated_at", ""),
            "last_verified_at": m.get("last_verified_at", ""),
            "last_verified_commit": m.get("last_verified_commit", ""),
            "superseded_by": m.get("superseded_by", ""),
        }
        cols = ",".join(row.keys())
        qs = ",".join("?" for _ in row)
        conn.execute(f"INSERT INTO memories ({cols}) VALUES ({qs})", list(row.values()))
        if fts_available:
            fts_cols = [
                "id", "repo_id", "scope", "namespace", "type", "status", "claim", "why",
                "applicability", "verification", "tags", "task_types", "entities", "evidence",
            ]
            conn.execute(
                f"INSERT INTO memory_fts ({','.join(fts_cols)}) VALUES ({','.join('?' for _ in fts_cols)})",
                [row[c] for c in fts_cols],
            )
    conn.commit()
    conn.close()
    meta = {"rebuilt_at": utc_now(), "fts_available": fts_available, "memory_count": len(load_memories(include_rejected=True))}
    write_json(INDEX / "last-rebuild.json", meta)
    print(f"Rebuilt memory index at {DB_PATH} (fts_available={fts_available}, count={meta['memory_count']})")


def rebuild_index_quiet() -> None:
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rebuild_index()


def init_cmd(_: argparse.Namespace) -> None:
    ensure_dirs()
    if not CONFIG_PATH.exists():
        write_json(CONFIG_PATH, DEFAULT_CONFIG)
        print(f"Created {CONFIG_PATH.relative_to(ROOT)}")
    rebuild_index()
    print("Brain memory initialized.")


def ensure_index() -> None:
    ensure_dirs()
    if not DB_PATH.exists():
        rebuild_index()


def expand_query(query: str, task_type: Optional[str], cfg: Dict[str, Any]) -> Tuple[str, List[str]]:
    expansions: List[str] = []
    task_expansions = cfg.get("task_expansions", {}) or {}
    if task_type and task_type in task_expansions:
        expansions.extend(task_expansions[task_type])
    q_tokens = set(tokenize(query))
    # Light auto-detection: if task_type is omitted, add expansion only when
    # the query has a meaningful category signal. A single common overlap
    # like "memory" should not pull in a whole unrelated expansion set.
    if not task_type:
        strong_single_signal_tasks = {"rationale", "refactoring"}
        strong_single_signal_terms = {
            "why", "rationale", "intent", "decision", "legacy", "workaround",
            "constraint", "tradeoff", "refactor", "simplify", "remove", "delete"
        }
        for name, terms in task_expansions.items():
            name_tokens = set(tokenize(name.replace('-', ' '))) | set(tokenize(name))
            term_tokens = set(tokenize(" ".join(terms)))
            overlap = q_tokens & term_tokens
            strong_single_signal = name in strong_single_signal_tasks and bool(overlap & strong_single_signal_terms)
            if (q_tokens & name_tokens) or len(overlap) >= 2 or strong_single_signal:
                expansions.extend(terms[:12])
    expanded = query + " " + " ".join(expansions)
    return expanded, sorted(set(expansions))


def fts_query_from_text(text: str) -> str:
    toks = tokenize(text)
    # FTS5 implicit AND can be too strict. Use OR between tokens, quote tokens with punctuation.
    safe = []
    for t in toks[:48]:
        t = t.replace('"', '""')
        safe.append(f'"{t}"')
    return " OR ".join(safe) if safe else '"memory"'


def recall_cmd(args: argparse.Namespace) -> None:
    cfg = load_config()
    ensure_index()
    budget = cfg.get("budgets", {}).get(args.budget, cfg["budgets"]["small"])
    limit = int(args.limit or budget.get("limit", 5))
    max_chars = int(args.max_chars or budget.get("max_chars", 2500))
    min_score = float(args.min_score if args.min_score is not None else budget.get("min_score", 0.0))
    include_quiet = bool(args.include_quiet or budget.get("include_quiet", False))
    include_held = bool(args.include_held or budget.get("include_held", False))
    repo_id = args.repo_id or default_repo_id()
    expanded_query, expansions = expand_query(args.query, args.task_type, cfg)
    statuses = ["active"]
    if include_quiet:
        statuses.append("quiet")
    if include_held:
        statuses.append("held")

    results: List[Tuple[float, Dict[str, Any], str]] = []
    if DB_PATH.exists():
        try:
            conn = sqlite3.connect(DB_PATH)
            conn.row_factory = sqlite3.Row
            fts = fts_query_from_text(expanded_query)
            rows = conn.execute(
                """
                SELECT m.*, bm25(memory_fts) AS rank
                FROM memory_fts
                JOIN memories m ON m.id = memory_fts.id
                WHERE memory_fts MATCH ?
                """,
                (fts,),
            ).fetchall()
            conn.close()
            for r in rows:
                m = dict(r)
                if m.get("status") not in statuses:
                    continue
                if args.namespace and m.get("namespace") != args.namespace:
                    continue
                if not args.include_other_repos:
                    if m.get("repo_id") not in (repo_id, "global", "") and m.get("scope") not in ("workspace", "global"):
                        continue
                score = score_memory(m, repo_id, args.query, expanded_query)
                if score < min_score:
                    continue
                reason = retrieval_reason(m, repo_id, args.query, expansions)
                results.append((score, m, reason))
        except Exception as e:
            print(f"Warning: SQLite recall failed, falling back to file scan: {e}", file=sys.stderr)
            results = []
    if not results:
        for _, m in load_memories(include_rejected=False):
            if m.get("status") not in statuses:
                continue
            if args.namespace and m.get("namespace") != args.namespace:
                continue
            if not args.include_other_repos:
                if m.get("repo_id") not in (repo_id, "global", "") and m.get("scope") not in ("workspace", "global"):
                    continue
            text = searchable_text(m)
            if not (token_set(expanded_query) & token_set(text)):
                continue
            score = score_memory(m, repo_id, args.query, expanded_query)
            if score < min_score:
                continue
            results.append((score, m, retrieval_reason(m, repo_id, args.query, expansions)))

    results.sort(key=lambda x: x[0], reverse=True)
    print("# Brain Recall")
    print(f"Query: {args.query}")
    print(f"Repo: {repo_id}")
    print(f"Budget: {args.budget} (limit={limit}, max_chars={max_chars}, min_score={min_score})")
    if args.task_type:
        print(f"Task type: {args.task_type}")
    if expansions:
        print(f"Expanded terms: {', '.join(expansions[:20])}{'...' if len(expansions) > 20 else ''}")
    print()
    if not results:
        print("No relevant memories found. Continue normally; memory is optional.")
        return

    used = 0
    emitted = 0
    for score, m, reason in results:
        stale_missing = evidence_missing(m)
        stale_changed = evidence_changed_since_verify(m)
        stale = bool(stale_missing or stale_changed)
        block = compact_summary(m, stale=stale, reason=reason)
        if stale_missing:
            block += f"\n  Stale warning: missing evidence: {', '.join(stale_missing[:3])}"
        if stale_changed:
            block += f"\n  Stale warning: evidence changed since verification: {', '.join(stale_changed[:3])}"
        if used + len(block) > max_chars and emitted > 0:
            break
        print(block)
        print(f"  Score: {score:.2f} | id={m.get('id')}")
        print()
        used += len(block)
        emitted += 1
        if emitted >= limit:
            break
    print("Use these memories as hints only. Verify against current source code.")


def searchable_text(m: Dict[str, Any]) -> str:
    fields = [
        m.get("repo_id", ""), m.get("scope", ""), m.get("namespace", ""), m.get("type", ""),
        m.get("status", ""), m.get("claim", ""), m.get("why", ""), m.get("applicability", ""),
        m.get("verification", ""), " ".join(as_list(m.get("tags"))), " ".join(as_list(m.get("task_types"))),
        " ".join(as_list(m.get("entities"))), " ".join(as_list(m.get("evidence"))),
    ]
    return " ".join(fields)


def feedback_adjustment(memory_id: str) -> float:
    if not memory_id or not FEEDBACK.exists():
        return 0.0
    adjustment = 0.0
    for p in FEEDBACK.glob("*.json"):
        try:
            fb = read_json(p)
        except Exception:
            continue
        if fb.get("memory_id") != memory_id:
            continue
        signal = fb.get("signal")
        if signal == "helpful":
            adjustment += 0.6
        elif signal == "irrelevant":
            adjustment -= 2.0
        elif signal == "stale":
            adjustment -= 1.5
        elif signal == "too_generic":
            adjustment -= 1.2
        elif signal == "wrong_scope":
            adjustment -= 1.4
    return adjustment


def score_memory(m: Dict[str, Any], current_repo: str, query: str, expanded_query: str) -> float:
    # Relevance should dominate trust/scope boosts. A same-repo active memory
    # should not outrank a more relevant held/workspace memory for a deep recall.
    text = searchable_text(m)
    q_tokens = token_set(query)
    expanded_tokens = token_set(expanded_query)
    text_tokens = token_set(text)
    tags = set(t.lower() for t in as_list(m.get("tags")))
    task_types = set(t.lower() for t in as_list(m.get("task_types")))
    entities = set(t.lower() for t in as_list(m.get("entities")))
    evidence_tokens = token_set(" ".join(as_list(m.get("evidence"))))

    score = 0.0
    score += 28 * jaccard(query, text)
    score += 12 * jaccard(expanded_query, text)
    score += 2.5 * len(q_tokens & tags)
    score += 2.0 * len(q_tokens & entities)
    score += 1.5 * len(q_tokens & evidence_tokens)
    score += 0.35 * min(len(expanded_tokens & text_tokens), 10)

    if m.get("repo_id") == current_repo:
        score += 1.5
    if m.get("scope") == "repo" and m.get("repo_id") == current_repo:
        score += 1.0
    elif m.get("scope") == "workspace":
        score += 0.7
    elif m.get("scope") == "global":
        score += 0.3

    conf = m.get("confidence")
    if conf == "confirmed":
        score += 1.0
    elif conf == "likely":
        score += 0.5

    status = m.get("status")
    if status == "active":
        score += 0.8
    elif status == "quiet":
        score -= 0.4
    elif status == "held":
        score -= 0.8

    score += feedback_adjustment(m.get("id", ""))

    # Keep recall scoring cheap. Expensive git-based stale checks are performed
    # only for emitted results and maintenance/review commands.
    if evidence_missing(m):
        score -= 1.5
    return score


def retrieval_reason(m: Dict[str, Any], current_repo: str, query: str, expansions: List[str]) -> str:
    reasons: List[str] = []
    if m.get("repo_id") == current_repo:
        reasons.append("current repo")
    elif m.get("scope") in ("workspace", "global"):
        reasons.append(f"{m.get('scope')} scope")
    qt = token_set(query)
    tags = set(t.lower() for t in as_list(m.get("tags")))
    ents = set(t.lower() for t in as_list(m.get("entities")))
    evs = token_set(" ".join(as_list(m.get("evidence"))))
    if qt & tags:
        reasons.append("tag match")
    if qt & ents:
        reasons.append("entity match")
    if qt & evs:
        reasons.append("path/evidence match")
    if set(tokenize(" ".join(expansions))) & token_set(searchable_text(m)):
        reasons.append("task expansion match")
    if not reasons:
        reasons.append("text relevance")
    return ", ".join(reasons)


def validate_proposal(m: Dict[str, Any], cfg: Dict[str, Any]) -> List[str]:
    reasons: List[str] = []
    if m.get("type") not in cfg.get("allowed_types", []):
        reasons.append("invalid_type")
    if m.get("scope") not in cfg.get("allowed_scopes", []):
        reasons.append("invalid_scope")
    if m.get("confidence") not in cfg.get("allowed_confidence", []):
        reasons.append("invalid_confidence")
    if not m.get("repo_id"):
        reasons.append("missing_repo_id")
    if not m.get("namespace"):
        reasons.append("missing_namespace")
    elif not valid_namespace(str(m.get("namespace"))):
        reasons.append("invalid_namespace_format")
    if len((m.get("claim") or "").strip()) < 25:
        reasons.append("claim_too_short")
    if len((m.get("why") or "").strip()) < 20:
        reasons.append("why_too_short")
    if is_generic(m.get("claim", "")):
        reasons.append("generic_claim")
    if contains_blocked_sensitive(m, cfg):
        reasons.append("possible_secret_or_sensitive_data")
    ev = m.get("evidence") or []
    evidence_problems = validate_evidence_entries(m)
    reasons.extend(evidence_problems)
    for ev in as_list(m.get("evidence")):
        if isinstance(ev, str) and ev.startswith("commit:"):
            sha = ev.split(":", 1)[1].strip()
            if not git_commit_exists(sha):
                reasons.append(f"invalid_commit_evidence:{sha}")
    scope = m.get("scope")
    is_safe_global_agent_rule = scope == "global" and m.get("namespace") in ("agent.behavior", "agent.workflow", "agent.validation")
    if not ev and not is_safe_global_agent_rule:
        reasons.append("missing_evidence")
    if scope == "repo" and cfg.get("routing", {}).get("require_evidence_for_repo_memories", True) and not ev:
        reasons.append("missing_repo_evidence")
    if scope == "workspace" and cfg.get("routing", {}).get("require_evidence_for_workspace_memories", True) and not ev:
        reasons.append("missing_workspace_evidence")
    return reasons


def is_generic(claim: str) -> bool:
    c = claim.lower().strip()
    if any(p in c for p in GENERIC_PHRASES):
        return True
    toks = token_set(c)
    return len(toks) < 4


def contains_blocked_sensitive(m: Dict[str, Any], cfg: Dict[str, Any]) -> bool:
    # Block likely secret VALUES, not safe negative guidance such as
    # "Do not store API token values in memory."
    text = json.dumps(m).lower()
    claim = (m.get("claim") or "").lower().strip()
    namespace = (m.get("namespace") or "").lower()
    safe_negative_security_guidance = (
        namespace.startswith("security.")
        and claim.startswith(("do not store", "never store", "avoid storing", "do not persist", "never persist"))
    )
    secret_value_patterns = [
        r"(password|passwd|secret|token|api[_-]?key|client[_-]?secret|access[_-]?key|refresh[_-]?token)\s*[:=]\s*['\"]?[^'\"\s,]{8,}",
        r"-----begin [a-z ]*private key-----",
        r"\b\d{3}-\d{2}-\d{4}\b",
    ]
    if any(re.search(pat, text) for pat in secret_value_patterns):
        return True
    if safe_negative_security_guidance:
        return False
    # Still hold/reject obvious sensitive-data claims when not framed as safety guidance.
    for term in cfg.get("security", {}).get("blocked_sensitive_terms", []):
        if term.lower() in text:
            return True
    return False


def list_similarity(a: Any, b: Any) -> float:
    sa = set(x.lower() for x in as_list(a))
    sb = set(x.lower() for x in as_list(b))
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def find_duplicates(proposal: Dict[str, Any], memories: List[Tuple[Path, Dict[str, Any]]], cfg: Dict[str, Any]) -> Tuple[Optional[Tuple[Path, Dict[str, Any], float]], Optional[Tuple[Path, Dict[str, Any], float]]]:
    dupe_th = cfg.get("routing", {}).get("duplicate_jaccard_threshold", 0.72)
    near_th = cfg.get("routing", {}).get("near_duplicate_jaccard_threshold", 0.58)
    best: Optional[Tuple[Path, Dict[str, Any], float]] = None
    for p, m in memories:
        if m.get("status") not in ("active", "quiet"):
            continue
        # Only dedupe within same repo/scope/workspace/global or same namespace. Prevent unrelated merge.
        if m.get("repo_id") != proposal.get("repo_id") and m.get("scope") == "repo" and proposal.get("scope") == "repo":
            continue
        claim_sim = jaccard(proposal.get("claim", ""), m.get("claim", ""))
        tag_sim = list_similarity(proposal.get("tags"), m.get("tags"))
        entity_sim = list_similarity(proposal.get("entities"), m.get("entities"))
        evidence_sim = list_similarity(proposal.get("evidence"), m.get("evidence"))
        same_namespace = proposal.get("namespace") == m.get("namespace")
        # Composite score catches semantically duplicate proposals that use
        # different wording but share the same topic, entities, tags, and evidence.
        score = (0.50 * claim_sim) + (0.18 * tag_sim) + (0.16 * entity_sim) + (0.16 * evidence_sim)
        if same_namespace:
            score += 0.08
        # Strong metadata overlap in the same namespace is a duplicate even
        # when the claim phrasing differs. This is important for agent-written memories.
        if same_namespace and tag_sim >= 0.60 and (entity_sim >= 0.50 or evidence_sim >= 0.50):
            score = max(score, dupe_th + 0.01)
        if best is None or score > best[2]:
            best = (p, m, score)
    if best and best[2] >= dupe_th:
        return best, best
    if best and best[2] >= near_th:
        return None, best
    return None, None


def route_proposal(m: Dict[str, Any], cfg: Dict[str, Any]) -> Tuple[str, List[str], Optional[Tuple[Path, Dict[str, Any], float]]]:
    reasons = validate_proposal(m, cfg)
    routing = cfg.get("routing", {})
    all_mems = load_memories(include_rejected=False)
    duplicate, near_duplicate = find_duplicates(m, all_mems, cfg)
    if duplicate:
        return "merged", [f"duplicate_of:{duplicate[1].get('id')}", f"similarity:{duplicate[2]:.2f}"], duplicate
    if "possible_secret_or_sensitive_data" in reasons:
        return "rejected", reasons, None
    if "generic_claim" in reasons or "claim_too_short" in reasons or "why_too_short" in reasons:
        return "rejected", reasons, None
    if any(r.startswith("invalid_") or r.startswith("outside_repo_evidence") or r.startswith("missing_evidence_path") for r in reasons):
        return "held", reasons, None
    if near_duplicate:
        return "held", [f"near_duplicate_of:{near_duplicate[1].get('id')}", f"similarity:{near_duplicate[2]:.2f}"], near_duplicate
    if m.get("scope") == "global" and routing.get("hold_global_scope_by_default", True):
        return "held", ["global_scope_requires_manual_promotion"], None
    if m.get("scope") == "workspace" and routing.get("hold_workspace_scope_by_default", True):
        return "held", ["workspace_scope_requires_review"], None
    if m.get("confidence") == "speculative" and routing.get("hold_speculative_claims", True):
        return "held", ["speculative_confidence"], None
    if "missing_evidence" in reasons or "missing_repo_evidence" in reasons or "missing_workspace_evidence" in reasons:
        return "held", reasons, None
    if broad_claim(m.get("claim", "")) and m.get("scope") != "repo":
        return "held", ["broad_claim_non_repo_scope"], None
    if broad_claim(m.get("claim", "")) and m.get("confidence") != "confirmed":
        return "held", ["broad_claim_requires_confirmed_confidence"], None
    return "promoted", [], None


def broad_claim(claim: str) -> bool:
    c = claim.lower()
    return any(w in c for w in ["always", "never", "all ", "every ", "must "])


def learn_cmd(args: argparse.Namespace) -> None:
    cfg = load_config()
    ensure_dirs()
    repo_id = args.repo_id or default_repo_id()
    now = utc_now()
    proposal: Dict[str, Any] = {
        "id": new_id("mem", args.claim),
        "schema_version": VERSION,
        "repo_id": repo_id,
        "scope": args.scope,
        "namespace": args.namespace,
        "type": args.type,
        "status": "held",  # route decides final status
        "claim": args.claim.strip(),
        "why": args.why.strip(),
        "applicability": (args.applicability or f"Use for {args.namespace} work when the current code and evidence still support the claim.").strip(),
        "not_applicable_when": (args.not_applicable_when or "Do not apply when current source code or newer memory contradicts this claim.").strip(),
        "verification": (args.verification or "Verify against the listed evidence and current source code before relying on this memory.").strip(),
        "confidence": args.confidence,
        "tags": split_csv(args.tags),
        "task_types": split_csv(args.task_types),
        "entities": split_csv(args.entities),
        "evidence": normalize_evidence_entries(split_csv(args.evidence)),
        "created_at": now,
        "updated_at": now,
        "created_from_branch": current_branch(),
        "created_from_commit": current_commit(),
        "last_verified_at": now if args.confidence in ("likely", "confirmed") else "",
        "last_verified_commit": current_commit() if args.confidence in ("likely", "confirmed") else "",
        "routing": {},
    }
    outcome, reasons, related = route_proposal(proposal, cfg)
    if outcome == "promoted":
        proposal["status"] = "active"
        proposal["routing"] = {"outcome": "promoted", "reasons": reasons, "routed_at": now}
        path = memory_path(proposal)
        write_json(path, proposal)
        print(f"promoted {proposal['id']} -> {path.relative_to(ROOT)}")
    elif outcome == "merged" and related:
        p, existing, score = related
        existing.setdefault("merged_from", []).append({
            "id": proposal["id"],
            "claim": proposal["claim"],
            "why": proposal["why"],
            "evidence": as_list(proposal.get("evidence")),
            "tags": as_list(proposal.get("tags")),
            "merged_at": now,
            "similarity": score,
        })
        existing["tags"] = sorted(set(as_list(existing.get("tags")) + as_list(proposal.get("tags"))))
        existing["entities"] = sorted(set(as_list(existing.get("entities")) + as_list(proposal.get("entities"))))
        existing["evidence"] = sorted(set(as_list(existing.get("evidence")) + as_list(proposal.get("evidence"))))
        existing["updated_at"] = now
        write_json(p, existing)
        print(f"merged {proposal['id']} into {existing.get('id')} similarity={score:.2f}")
    elif outcome == "rejected":
        proposal["status"] = "rejected"
        proposal["routing"] = {"outcome": "rejected", "reasons": reasons, "routed_at": now}
        path = memory_path(proposal)
        write_json(path, proposal)
        print(f"rejected {proposal['id']} reasons={','.join(reasons)} -> {path.relative_to(ROOT)}")
    else:
        proposal["status"] = "held"
        proposal["routing"] = {"outcome": "held", "reasons": reasons, "routed_at": now}
        if related:
            proposal["related_memory_id"] = related[1].get("id")
            proposal["related_similarity"] = related[2]
        path = memory_path(proposal)
        write_json(path, proposal)
        print(f"held {proposal['id']} reasons={','.join(reasons)} -> {path.relative_to(ROOT)}")
    if args.defer_rebuild:
        print("index rebuild deferred; run memory.py rebuild before relying on recall")
    else:
        try:
            rebuild_index()
        except Exception as e:
            print(f"Warning: index rebuild failed: {e}", file=sys.stderr)


def promote_cmd(args: argparse.Namespace) -> None:
    found = find_memory_by_id(args.id)
    if not found:
        print(f"Memory not found: {args.id}", file=sys.stderr)
        sys.exit(1)
    path, m = found
    if m.get("scope") == "global" and not args.approve_global:
        print("Refusing to promote global memory without --approve-global", file=sys.stderr)
        sys.exit(2)
    if m.get("scope") == "workspace" and not args.approve_workspace and not args.approve_global:
        print("Refusing to promote workspace memory without --approve-workspace", file=sys.stderr)
        sys.exit(2)
    old = path
    m["status"] = "active"
    m["updated_at"] = utc_now()
    m.setdefault("routing", {})["manual_promotion"] = {"promoted_at": utc_now(), "approved_global": args.approve_global, "approved_workspace": args.approve_workspace}
    new_path = memory_path(m)
    write_json(new_path, m)
    if old != new_path and old.exists():
        old.unlink()
    rebuild_index()
    print(f"promoted {args.id} -> {new_path.relative_to(ROOT)}")


def reject_cmd(args: argparse.Namespace) -> None:
    found = find_memory_by_id(args.id)
    if not found:
        print(f"Memory not found: {args.id}", file=sys.stderr)
        sys.exit(1)
    path, m = found
    old = path
    m["status"] = "rejected"
    m["updated_at"] = utc_now()
    m["rejection_reason"] = args.reason or "manual_reject"
    new_path = memory_path(m)
    write_json(new_path, m)
    if old != new_path and old.exists():
        old.unlink()
    rebuild_index()
    print(f"rejected {args.id} -> {new_path.relative_to(ROOT)}")


def quiet_cmd(args: argparse.Namespace) -> None:
    found = find_memory_by_id(args.id)
    if not found:
        print(f"Memory not found: {args.id}", file=sys.stderr)
        sys.exit(1)
    path, m = found
    if m.get("status") not in ("active", "quiet"):
        print(f"Can only quiet active/quiet memories, got status={m.get('status')}", file=sys.stderr)
        sys.exit(2)
    m["status"] = "quiet"
    m["updated_at"] = utc_now()
    write_json(path, m)
    rebuild_index()
    print(f"quieted {args.id}")


def supersede_cmd(args: argparse.Namespace) -> None:
    old_found = find_memory_by_id(args.id)
    new_found = find_memory_by_id(args.by)
    if not old_found or not new_found:
        print("Old or new memory not found", file=sys.stderr)
        sys.exit(1)
    old_path, old = old_found
    old["status"] = "superseded"
    old["superseded_by"] = args.by
    old["updated_at"] = utc_now()
    write_json(old_path, old)
    rebuild_index()
    print(f"superseded {args.id} by {args.by}")


def verify_cmd(args: argparse.Namespace) -> None:
    found = find_memory_by_id(args.id)
    if not found:
        print(f"Memory not found: {args.id}", file=sys.stderr)
        sys.exit(1)
    path, m = found
    m["last_verified_at"] = utc_now()
    m["last_verified_commit"] = args.commit or current_commit()
    m["updated_at"] = utc_now()
    write_json(path, m)
    rebuild_index()
    print(f"verified {args.id} at commit {m['last_verified_commit']}")


def feedback_cmd(args: argparse.Namespace) -> None:
    ensure_dirs()
    record = {
        "id": new_id("fb", args.id + args.signal),
        "memory_id": args.id,
        "signal": args.signal,
        "query": args.query or "",
        "note": args.note or "",
        "created_at": utc_now(),
        "repo_id": args.repo_id or default_repo_id(),
    }
    path = FEEDBACK / f"{record['id']}.json"
    write_json(path, record)
    print(f"feedback recorded -> {path.relative_to(ROOT)}")


def stats_cmd(_: argparse.Namespace) -> None:
    ensure_dirs()
    counts: Dict[str, int] = {}
    scopes: Dict[str, int] = {}
    namespaces: Dict[str, int] = {}
    stale_missing = 0
    stale_changed = 0
    for _, m in load_memories(include_rejected=True):
        counts[m.get("status", "unknown")] = counts.get(m.get("status", "unknown"), 0) + 1
        scopes[m.get("scope", "unknown")] = scopes.get(m.get("scope", "unknown"), 0) + 1
        ns = m.get("namespace", "unknown")
        namespaces[ns] = namespaces.get(ns, 0) + 1
        if evidence_missing(m):
            stale_missing += 1
        if evidence_changed_since_verify(m):
            stale_changed += 1
    print("# Brain Memory Stats")
    print(f"Repo: {default_repo_id()}")
    print(f"Root: {ROOT}")
    print("\nStatus counts:")
    for k, v in sorted(counts.items()):
        print(f"- {k}: {v}")
    print("\nScope counts:")
    for k, v in sorted(scopes.items()):
        print(f"- {k}: {v}")
    print("\nTop namespaces:")
    for k, v in sorted(namespaces.items(), key=lambda x: x[1], reverse=True)[:10]:
        print(f"- {k}: {v}")
    print(f"\nStale/missing evidence memories: {stale_missing}")
    print(f"Changed-since-verify memories: {stale_changed}")
    print(f"Feedback records: {len(list(FEEDBACK.glob('*.json'))) if FEEDBACK.exists() else 0}")
    if DB_PATH.exists():
        print(f"Index: {DB_PATH.relative_to(ROOT)}")
    else:
        print("Index: missing; run rebuild")


def review_cmd(_: argparse.Namespace) -> None:
    print("# Brain Review")
    held = [(p, m) for p, m in load_memories(include_rejected=False) if m.get("status") == "held"]
    if not held:
        print("No held memories.")
    else:
        print(f"Held memories: {len(held)}\n")
        for p, m in held[:30]:
            print(compact_summary(m))
            reasons = (m.get("routing") or {}).get("reasons") or []
            if reasons:
                print(f"  Held because: {', '.join(reasons)}")
            print(f"  Path: {p.relative_to(ROOT)}")
            promote_cmd = f"python .github/skills/brain-memory/memory.py promote --id {m.get('id')}"
            if m.get("scope") == "global":
                promote_cmd += " --approve-global"
            elif m.get("scope") == "workspace":
                promote_cmd += " --approve-workspace"
            print(f"  Promote: {promote_cmd}")
            print(f"  Reject:  python .github/skills/brain-memory/memory.py reject --id {m.get('id')} --reason \"<reason>\"")
            print()
    # Stale active memories
    stale = []
    for p, m in load_memories(include_rejected=False):
        if m.get("status") in ("active", "quiet") and (evidence_missing(m) or evidence_changed_since_verify(m)):
            stale.append((p, m))
    if stale:
        print(f"Stale evidence warnings: {len(stale)}")
        for p, m in stale[:20]:
            print(f"- {m.get('id')} {m.get('claim')}")
            missing = evidence_missing(m)
            changed = evidence_changed_since_verify(m)
            if missing:
                print(f"  Missing: {', '.join(missing[:3])}")
            if changed:
                print(f"  Changed: {', '.join(changed[:3])}")
            print(f"  Path: {p.relative_to(ROOT)}")




def redact_sensitive_text(text: str) -> str:
    patterns = [
        r"(password|passwd|secret|token|api[_-]?key|client[_-]?secret|access[_-]?key|refresh[_-]?token)(\s*[:=]\s*)['\"]?[^'\"\s,}]{8,}",
        r"-----begin [a-z ]*private key-----.*?-----end [a-z ]*private key-----",
        r"\b\d{3}-\d{2}-\d{4}\b",
    ]
    out = text
    for pat in patterns:
        out = re.sub(pat, lambda m: (m.group(1) + m.group(2) + "[REDACTED]") if len(m.groups()) >= 2 else "[REDACTED]", out, flags=re.IGNORECASE | re.DOTALL)
    return out


def sanitize_payload(payload: Any, max_chars: int = 20000) -> Any:
    # Store only a redacted/truncated local signal. Local hook logs are ignored by git,
    # but they can still contain sensitive terminal/tool output if not scrubbed.
    try:
        text = json.dumps(payload, sort_keys=True)
        redacted = redact_sensitive_text(text)[:max_chars]
        return json.loads(redacted)
    except Exception:
        return {"text": redact_sensitive_text(str(payload))[:max_chars]}

def hook_session_start(_: argparse.Namespace) -> None:
    ensure_dirs()
    if not DB_PATH.exists():
        try:
            rebuild_index_quiet()
        except Exception as e:
            print(json.dumps({"additionalContext": f"Brain memory is available but index rebuild failed: {e}"}))
            return
    context = (
        f"Brain memory is available for this repo. repo_id={default_repo_id()}. "
        "For non-trivial engineering work, use the brain-memory skill for compact recall. "
        "Memory is a hint; current code wins."
    )
    print(json.dumps({"additionalContext": context}))


def hook_post_tool_use(_: argparse.Namespace) -> None:
    ensure_dirs()
    payload = sanitize_payload(read_stdin_json_or_text())
    event = {"id": new_id("event", "postToolUse"), "type": "postToolUse", "created_at": utc_now(), "payload": payload}
    append_jsonl(LOCAL / "session-events.jsonl", event)
    # Cheap maintenance: rebuild if memory source files changed according to payload text.
    text = json.dumps(payload).lower()
    if ".ai/brain/memories" in text or ".ai/brain/held" in text or ".ai/brain/rejected" in text:
        try:
            rebuild_index_quiet()
        except Exception as e:
            print(json.dumps({"additionalContext": f"Brain memory index rebuild failed after memory file change: {e}"}))
            return
    print(json.dumps({}))


def hook_pre_compact(_: argparse.Namespace) -> None:
    ensure_dirs()
    payload = sanitize_payload(read_stdin_json_or_text())
    checkpoint = LOCAL / "pre-compact-checkpoints" / f"{dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')}.json"
    write_json(checkpoint, {"created_at": utc_now(), "payload": payload})
    print(json.dumps({"additionalContext": "Saved a local brain-memory pre-compact checkpoint. Use /brain-scan if important learnings should be captured."}))


def hook_pre_tool_use(_: argparse.Namespace) -> None:
    payload = read_stdin_json_or_text()
    text = json.dumps(payload).lower()
    # Conservative guardrails; exact hook output semantics vary by surface.
    if ".ai/brain/index" in text:
        print(json.dumps({"decision": "deny", "reason": "Do not edit generated brain memory index files. Use memory.py rebuild."}))
        return
    cfg = load_config()
    if ".ai/brain" in text:
        secret_value_patterns = [
            r"(password|passwd|secret|token|api[_-]?key|client[_-]?secret|access[_-]?key|refresh[_-]?token)\s*[:=]\s*['\"]?[^'\"\s,]{8,}",
            r"-----begin [a-z ]*private key-----",
            r"\b\d{3}-\d{2}-\d{4}\b",
        ]
        if any(re.search(pat, text) for pat in secret_value_patterns):
            print(json.dumps({"decision": "deny", "reason": "Potential secret/sensitive value write to brain memory blocked."}))
            return
    print(json.dumps({}))


def read_stdin_json_or_text() -> Any:
    data = sys.stdin.read()
    if not data:
        return {}
    try:
        return json.loads(data)
    except Exception:
        return {"text": data[:20000]}


def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, sort_keys=True) + "\n")


def branch_summary_cmd(_: argparse.Namespace) -> None:
    branch = current_branch()
    print(f"# Brain Branch Summary: {branch}")
    commit = current_commit()
    print(f"Current commit: {commit}\n")
    # This is intentionally simple; use git diff for tracked memory changes.
    changed = run_git(["status", "--short", ".ai/brain"]) or ""
    if changed.strip():
        print("Changed brain files:")
        print(changed)
    else:
        print("No changed brain files detected.")


def main() -> None:
    parser = argparse.ArgumentParser(description="Repo-local Copilot brain memory CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("init")
    p.set_defaults(func=init_cmd)

    p = sub.add_parser("rebuild")
    p.set_defaults(func=lambda args: rebuild_index())

    p = sub.add_parser("rebuild-if-needed")
    p.set_defaults(func=lambda args: rebuild_index() if not DB_PATH.exists() else print("Index exists."))

    p = sub.add_parser("prime-session")
    p.add_argument("--repo-id")
    p.add_argument("--limit", type=int)
    p.add_argument("--max-chars", type=int)
    p.add_argument("--min-score", type=float)
    p.add_argument("--include-stale", action="store_true")
    p.set_defaults(func=prime_session_cmd)

    p = sub.add_parser("recall")
    p.add_argument("--query", required=True)
    p.add_argument("--budget", default="small", choices=["small", "medium", "deep", "review"])
    p.add_argument("--task-type")
    p.add_argument("--repo-id")
    p.add_argument("--namespace")
    p.add_argument("--limit", type=int)
    p.add_argument("--max-chars", type=int)
    p.add_argument("--min-score", type=float)
    p.add_argument("--include-quiet", action="store_true")
    p.add_argument("--include-held", action="store_true")
    p.add_argument("--include-other-repos", action="store_true")
    p.set_defaults(func=recall_cmd)

    p = sub.add_parser("learn")
    p.add_argument("--type", required=True, choices=["lesson", "pattern", "trap", "validation"])
    p.add_argument("--repo-id", default=None)
    p.add_argument("--scope", default="repo", choices=["repo", "workspace", "global"])
    p.add_argument("--namespace", default="implementation.patterns")
    p.add_argument("--claim", required=True)
    p.add_argument("--why", required=True)
    p.add_argument("--applicability", default="")
    p.add_argument("--not-applicable-when", dest="not_applicable_when", default="")
    p.add_argument("--verification", default="")
    p.add_argument("--confidence", default="likely", choices=["speculative", "likely", "confirmed"])
    p.add_argument("--tags", default="")
    p.add_argument("--task-types", default="")
    p.add_argument("--entities", default="")
    p.add_argument("--evidence", default="")
    p.add_argument("--defer-rebuild", action="store_true", help="Write/route the memory but skip index rebuild; run rebuild after bulk learn operations.")
    p.set_defaults(func=learn_cmd)

    p = sub.add_parser("promote")
    p.add_argument("--id", required=True)
    p.add_argument("--approve-workspace", action="store_true")
    p.add_argument("--approve-global", action="store_true")
    p.set_defaults(func=promote_cmd)

    p = sub.add_parser("reject")
    p.add_argument("--id", required=True)
    p.add_argument("--reason", default="manual_reject")
    p.set_defaults(func=reject_cmd)

    p = sub.add_parser("quiet")
    p.add_argument("--id", required=True)
    p.set_defaults(func=quiet_cmd)

    p = sub.add_parser("supersede")
    p.add_argument("--id", required=True)
    p.add_argument("--by", required=True)
    p.set_defaults(func=supersede_cmd)

    p = sub.add_parser("verify")
    p.add_argument("--id", required=True)
    p.add_argument("--commit")
    p.set_defaults(func=verify_cmd)

    p = sub.add_parser("feedback")
    p.add_argument("--id", required=True)
    p.add_argument("--signal", required=True, choices=["helpful", "irrelevant", "stale", "too_generic", "wrong_scope"])
    p.add_argument("--query", default="")
    p.add_argument("--note", default="")
    p.add_argument("--repo-id", default=None)
    p.set_defaults(func=feedback_cmd)

    p = sub.add_parser("stats")
    p.set_defaults(func=stats_cmd)

    p = sub.add_parser("review")
    p.set_defaults(func=review_cmd)

    p = sub.add_parser("branch-summary")
    p.set_defaults(func=branch_summary_cmd)

    p = sub.add_parser("hook-session-start")
    p.set_defaults(func=hook_session_start)

    p = sub.add_parser("hook-post-tool-use")
    p.set_defaults(func=hook_post_tool_use)

    p = sub.add_parser("hook-pre-compact")
    p.set_defaults(func=hook_pre_compact)

    p = sub.add_parser("hook-pre-tool-use")
    p.set_defaults(func=hook_pre_tool_use)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
