# Brain Prime Session

Use this prompt at the beginning of a meaningful new Copilot agent/session in a repo that uses the brain-memory framework.

Prime-session is a supporting orientation step. Task-specific brain recall remains the flagship workflow and must still be run after the concrete task is known for non-trivial repo work.

## Steps

1. Run:

```bash
python -S .github/skills/brain-memory/memory.py prime-session
```

2. Read the compact baseline context.
3. Treat it as orientation only, not truth.
4. When the user gives the actual task, run targeted recall:

```bash
python -S .github/skills/brain-memory/memory.py recall --query "<task summary>" --budget small
```

5. Inspect current code before planning or editing.

## Guardrails

- Do not load the whole `.ai/brain` folder.
- Do not treat prime-session as a substitute for recall.
- Do not cite memory as proof without verifying current code/evidence.
- Skip prime-session for tiny mechanical edits.
- Skip task recall only for clearly trivial mechanical edits where prior repo knowledge would not affect the approach.
