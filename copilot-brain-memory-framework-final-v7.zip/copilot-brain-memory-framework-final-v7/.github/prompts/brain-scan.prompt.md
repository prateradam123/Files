---
description: Scan recent work for memory-worthy lessons, patterns, traps, or validation knowledge.
---

# Brain Scan

Scan what we just did for anything memory-worthy.

Use this when the user says something like:

- "scan this for memory"
- "this was important"
- "capture what we learned"
- "brain-scan this"
- "check if anything from that should become memory"

## Goal

Find durable repo-specific knowledge from the recent task/session and submit it to the brain memory system.

Use the `brain-memory` skill and `memory.py learn`.

Do not manually promote or edit memories.
Do not create filler memories.
Do not save generic advice.

## Inspect

Review available context:

1. Recent conversation/task findings
2. Current git diff
3. Files inspected or changed
4. Tests run or validation results
5. Dead ends or corrected assumptions
6. Existing memory recall to avoid duplicates

Useful commands:

```bash
git diff --stat
git diff --name-only
python -S .github/skills/brain-memory/memory.py recall \
  --query "<summary of recent work>" \
  --budget small
```

## Save only useful memory

Good memories are:

- lessons
- patterns
- traps
- validation lessons

They must be:

- reusable
- repo-specific or clearly scoped
- evidence-backed
- compact
- helpful to future Copilot work

Do not save:

- generic advice
- temporary debugging details
- secrets or sensitive data
- obvious facts
- unsupported speculation
- one-off implementation minutiae
- claims broader than the evidence

## Memory identity

For each memory proposal, include:

- `repo_id`: current repo identifier
- `scope`: usually `repo`
- `namespace`: generic topic area

Examples:

- `implementation.data-mapping`
- `testing.validation`
- `integration.messaging`
- `debugging.known-traps`
- `architecture.flow`
- `agent.workflow`

Specific domain/code names belong in `tags`, `entities`, and `evidence`.

## Learn command

```bash
python -S .github/skills/brain-memory/memory.py learn \
  --type trap \
  --repo-id "<current-repo-id>" \
  --scope repo \
  --namespace "implementation.data-mapping" \
  --claim "<short durable claim>" \
  --why "<why this helps future work>" \
  --applicability "<when to use this memory>" \
  --not-applicable-when "<when not to apply it>" \
  --verification "<how to verify before relying on it>" \
  --confidence likely \
  --tags "tag1,tag2,tag3" \
  --task-types "debugging,implementation" \
  --entities "ClassA,ClassB" \
  --evidence "path/to/file1,path/to/file2"
```

## Output

Respond with:

1. What was scanned
2. Memories promoted/merged/held/rejected
3. Observations skipped
4. Any held items that may need review

If nothing is memory-worthy, say so and do not create filler memory.
