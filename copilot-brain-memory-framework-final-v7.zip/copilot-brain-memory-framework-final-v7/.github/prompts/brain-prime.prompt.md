---
description: Seed the brain from an existing repository by scanning current code, recent commits, tests, and recurring patterns.
---

# Brain Prime

Prime the repo brain for an existing repository.

Use this when adding the brain memory system to a repo that already has meaningful code and history.

The goal is to create a small set of high-quality starter memories from current code and recent history.

Do not document the whole repo.
Do not create memories manually.
Use the `brain-memory` skill and `memory.py learn` so proposals are automatically promoted, merged, held, or rejected.

## Target output

Aim for 3-8 strong starter memories.

Prefer fewer, high-confidence memories over many weak ones.

Broad claims should be held unless strongly verified.

## Focus

Find durable knowledge that will help future Copilot work:

- repo-specific lessons
- implementation patterns
- known traps
- validation/test lessons
- important file relationships
- risky or non-obvious flows
- recurring investigation paths
- repeated change areas
- common validation paths

Avoid:

- generic coding advice
- stale history not supported by current code
- secrets or sensitive data
- obvious package/file facts
- one-off bug details that do not generalize
- broad architecture claims without evidence

## Memory identity

For each starter memory, include:

- `repo_id`: current repository identifier
- `scope`: usually `repo`
- `namespace`: generic topic area, such as `implementation.data-mapping`, `testing.validation`, `integration.messaging`, or `debugging.known-traps`

Do not put the repo name inside the namespace. Use `repo_id` for that.

Use repo-specific details in `tags`, `entities`, `claim`, and `evidence`.

## Suggested scan

Run from repo root as appropriate:

```bash
git rev-parse --show-toplevel
git status --short
git log --oneline --decorate -n 50
git log --name-only --pretty=format:'--- %h %s' -n 30
git log --name-only --pretty=format: -n 100 | sort | uniq -c | sort -nr | head -50
find . -maxdepth 4 -type f \( -name "pom.xml" -o -name "build.gradle" -o -name "package.json" -o -name "*.java" -o -name "*.kt" -o -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.xml" -o -name "*.yml" -o -name "*.yaml" -o -name "*.feature" \) | head -250
find . -type f \( -name "*Test.*" -o -name "*IT.*" -o -name "*.feature" -o -name "*.spec.*" \) | head -200
```

Use current code to verify anything suggested by commit history.

Commit history can suggest memories, but current code must confirm them.

## Create memory proposals

For each worthwhile observation, call:

```bash
python -S .github/skills/brain-memory/memory.py learn \
  --type pattern \
  --repo-id "<current-repo-id>" \
  --scope repo \
  --namespace "implementation.patterns" \
  --claim "<short durable claim>" \
  --why "<why this helps future Copilot work>" \
  --applicability "<when to use this memory>" \
  --not-applicable-when "<when not to apply it>" \
  --verification "<how to verify before relying on it>" \
  --confidence likely \
  --tags "tag1,tag2,tag3" \
  --task-types "implementation,debugging" \
  --entities "ClassOrComponentA,ConfigB" \
  --evidence "path/to/file1,path/to/file2,commit:abc123" \
  --defer-rebuild
```

After all prime learn calls, run:

```bash
python -S .github/skills/brain-memory/memory.py rebuild
```

## Output

Respond with:

1. Scope scanned
   - commit range
   - code areas
   - tests
   - recurring file hotspots

2. Memory proposals submitted
   - promoted
   - merged
   - held
   - rejected

3. Important observations skipped and why
   - stale
   - too generic
   - not enough evidence
   - duplicate

4. Recommended next use of the brain

Keep the output concise.
