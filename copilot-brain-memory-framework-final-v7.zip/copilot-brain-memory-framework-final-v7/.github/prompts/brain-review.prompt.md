---
description: Review held, rejected, duplicate, stale, or noisy brain memories. Rare maintenance command.
---

# Brain Review

Review brain memory health.

This is not required for normal daily work.

Use it when:

- held memories are piling up
- recall feels noisy
- a contradiction was found
- after a large brain-prime
- before committing memory changes
- the user asks to inspect memory quality

## Start

Run:

```bash
python -S .github/skills/brain-memory/memory.py stats
python -S .github/skills/brain-memory/memory.py review
```

## Review goals

For held memories:

- promote if narrow, durable, and evidence-backed
- reject if generic, stale, duplicate, temporary, unsupported, or wrong-scope
- leave held if still ambiguous
- narrow the claim if useful but too broad

For workspace/global held memories:

- promote only with explicit approval
- keep held unless the scope is clearly safe
- prefer repo scope unless reuse beyond the repo is justified

For rejected memories:

- usually leave them alone
- only restore if they were clearly misclassified

For duplicates:

- prefer one stronger memory
- merge evidence into existing memory
- avoid multiple memories that say the same thing

For stale memories:

- current code wins
- update or supersede the memory rather than silently ignoring the conflict

For contradictions:

- current code wins
- update, supersede, or hold the memory
- do not broaden claims beyond evidence

## Commands

```bash
python -S .github/skills/brain-memory/memory.py promote --id <memory-id>

python -S .github/skills/brain-memory/memory.py promote --id <memory-id> --approve-workspace

python -S .github/skills/brain-memory/memory.py promote --id <memory-id> --approve-global

python -S .github/skills/brain-memory/memory.py reject \
  --id <memory-id> \
  --reason "<reason>"

python -S .github/skills/brain-memory/memory.py quiet --id <memory-id>

python -S .github/skills/brain-memory/memory.py supersede \
  --id <old-memory-id> \
  --by <new-memory-id>

python -S .github/skills/brain-memory/memory.py rebuild
```

## Output

Respond with:

1. Counts reviewed
2. Promotions made
3. Rejections made
4. Memories quieted or superseded
5. Held items remaining
6. Stale evidence warnings
7. Recall quality concerns, if any
8. Suggested follow-up, if useful

Keep review concise. Do not turn this into a large memory report unless asked.
