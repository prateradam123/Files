# Copilot Brain Memory

This repository uses a lightweight brain memory system in `.ai/brain`.

The brain is agent-agnostic infrastructure. It applies regardless of which Copilot agent is selected.

## When to use it

Task-specific brain recall is the flagship feature of this framework. For non-trivial engineering work, use the `brain-memory` skill before planning or editing.

For a fresh agent/session doing meaningful repo work, run `prime-session` once to get compact baseline repo context. Prime-session is orientation only. It must not replace task-specific recall.

After the concrete task is known, run targeted task recall for non-trivial repo work even if prime-session was already run. Skip task recall only for clearly trivial mechanical edits where prior repo knowledge would not affect the work.

Use task recall for work involving:

- investigation
- debugging
- implementation planning
- cross-file behavior
- data or model mapping
- integrations
- tests and validation
- architecture-sensitive changes
- understanding why code, configuration, tests, workflows, or design choices exist
- removing, simplifying, refactoring, or replacing non-obvious code where prior rationale may matter
- anything likely to benefit from prior repo lessons, patterns, traps, rationale, or validation knowledge

Skip it for trivial work:

- formatting
- imports
- simple renames
- obvious one-file edits
- tiny syntax fixes

## How to treat memory

Memory is guidance, not truth.

Always verify against current source code. Current code beats memory.

When investigating rationale or intent, use recalled memory as a hypothesis, not proof. Verify it against current code, tests, commits, and evidence before explaining or changing behavior.

If memory conflicts with code, trust code and use the `brain-memory` skill to submit a held observation or contradiction note when useful.

## After meaningful work

If the task revealed a durable lesson, pattern, trap, or validation insight, use the `brain-memory` skill to submit it.

Do not manually edit generated memory indexes.

Do not store secrets, credentials, customer data, personal data, production identifiers, or sensitive internal details in memory.

Do not load the entire `.ai/brain` folder.

For all prime-session, recall, learning, routing, indexing, review, schema, and optional hook details, follow the `brain-memory` skill.
