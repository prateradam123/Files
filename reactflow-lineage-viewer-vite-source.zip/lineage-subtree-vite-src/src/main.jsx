import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Background,
  BaseEdge,
  Controls,
  EdgeLabelRenderer,
  Handle,
  MarkerType,
  MiniMap,
  Position,
  ReactFlow,
  ReactFlowProvider,
  getBezierPath,
  useEdgesState,
  useNodesState,
  useReactFlow,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { lineageReport } from './lineageData.js';
import './styles.css';

const KIND_LABELS = {
  object: 'Object',
  group: 'Nested object',
  array: 'List',
  field: 'Field',
  assignment: 'Assignment',
  transform: 'Transform',
  source: 'Source',
  repository: 'Database',
  event: 'Event',
  external: 'External',
  config: 'Config',
  constant: 'Constant',
  runtime: 'Runtime',
  method: 'Method',
  unknown: 'Unknown',
};

const KIND_SYMBOLS = {
  object: '{}',
  group: '{}',
  array: '[]',
  field: '•',
  assignment: '= ',
  transform: 'ƒ',
  source: 'src',
  repository: 'db',
  event: 'evt',
  external: 'api',
  config: 'cfg',
  constant: 'const',
  runtime: 'time',
  method: 'call',
  unknown: '?',
};

const EDGE_LEGEND = [
  { key: 'contains', label: 'Contains', text: 'Object shape relationship: parent object/list contains a child field or object.' },
  { key: 'assignment', label: 'Assigned by', text: 'The selected output field is populated by a setter, builder call, constructor arg, or mapper assignment.' },
  { key: 'transform', label: 'Computed / input', text: 'A derived value or one of the input branches that feeds a calculation, formatter, or selector.' },
  { key: 'boundary', label: 'Source boundary', text: 'The trace reached a DB, event, config, external service, runtime, or other origin boundary.' },
  { key: 'branch', label: 'Branch / fallback', text: 'Conditional logic, fallback values, selected alternatives, or branch-specific inputs.' },
  { key: 'unknown', label: 'Unresolved', text: 'The trace cannot continue because the source is dynamic, unavailable, or unclear.' },
  { key: 'flow', label: 'Value flow', text: 'General value movement through local variables, method returns, parameters, or helper calls.' },
];

const NODE_LEGEND = [
  { kind: 'object', label: 'Output object', text: 'Root DTO/message/request being built and sent.' },
  { kind: 'group', label: 'Nested object', text: 'A nested DTO section inside the output object.' },
  { kind: 'array', label: 'List', text: 'A repeated object/list such as reasons[] or vehicles[].' },
  { kind: 'field', label: 'Field', text: 'A concrete output property that receives a value.' },
  { kind: 'assignment', label: 'Assignment', text: 'Setter, builder call, constructor argument, mapper target, or copy operation.' },
  { kind: 'transform', label: 'Transform', text: 'Computed/derived logic. Every input to this node should be traced backward too.' },
  { kind: 'source', label: 'Source value', text: 'An intermediate value, entity property, method result, or local value feeding the assignment.' },
  { kind: 'repository', label: 'Database', text: 'Repository/DAO/query boundary where code-level tracing stops at persistence.' },
  { kind: 'event', label: 'Input event', text: 'Kafka/MQ/API request/input payload boundary.' },
  { kind: 'external', label: 'External API', text: 'Client/SDK/vendor/service boundary outside reachable source.' },
  { kind: 'config', label: 'Config', text: 'Property, environment variable, feature flag, or config service value.' },
  { kind: 'constant', label: 'Constant', text: 'Hardcoded, enum, static default, or template value.' },
  { kind: 'runtime', label: 'Runtime', text: 'Generated at runtime, such as clock time, UUID, or system context.' },
  { kind: 'unknown', label: 'Unknown', text: 'Unresolved path, dynamic reflection, generated code gap, or unavailable library.' },
];

const TERMINAL_KINDS = new Set(['repository', 'event', 'external', 'config', 'constant', 'runtime', 'unknown']);
const X_STEP = 286;
const Y_STEP = 150;
const SUBTREE_BRANCH_Y = 116;
const SUBTREE_LANE_GAP = 64;

function cx(...values) {
  return values.filter(Boolean).join(' ');
}

function confidenceClass(value) {
  return `conf-${String(value || 'medium').toLowerCase()}`;
}

function mapTypeClass(value) {
  return `map-${String(value || 'direct').replace(/[^a-z0-9]/gi, '-').toLowerCase()}`;
}

function edgeCategory(label = '', targetKind) {
  const value = String(label).toLowerCase();
  if (value.includes('contains')) return 'contains';
  if (value.includes('possibly') || value.includes('unresolved')) return 'unknown';
  if (value.includes('fallback') || value.includes('branch') || value.includes('selected')) return 'branch';
  if (value.includes('computed') || value === 'input' || value.includes('primary input') || value.includes('called with') || value.includes('uses key') || value === 'uses') return 'transform';
  if (value.includes('assigned')) return 'assignment';
  if (TERMINAL_KINDS.has(targetKind) || value.includes('loaded') || value.includes('returned') || value.includes('read') || value.includes('from ') || value.includes('bound') || value.includes('produced')) return 'boundary';
  return 'flow';
}

function getModeDescription(mode, isFieldSelection) {
  if (mode === 'shape') return 'Nested object shape only. Click any object/list to show descendant lineage, or a leaf field for one trace.';
  if (mode === 'subtree') return 'Every descendant leaf field under the selected object/list is rendered in its own lane.';
  return isFieldSelection
    ? 'Focused trace for one selected field. Object hierarchy appears first, then the backward value lineage.'
    : 'Focused trace for the selected object’s primary leaf field.';
}

function normalizeKind(schemaNode) {
  if (schemaNode.kind === 'object' && schemaNode.path !== '$') return 'group';
  return schemaNode.kind;
}

function getAllFields(schema = lineageReport.objectShape) {
  const results = [];
  function walk(node) {
    if (node.kind === 'field') results.push(node);
    (node.children || []).forEach(walk);
  }
  walk(schema);
  return results;
}

function getSchemaPath(nodePath, schema = lineageReport.objectShape) {
  const trail = [];
  function walk(node, chain) {
    const next = [...chain, node];
    if (node.path === nodePath) {
      trail.push(...next);
      return true;
    }
    return (node.children || []).some((child) => walk(child, next));
  }
  walk(schema, []);
  return trail;
}

function findSchemaNode(path, schema = lineageReport.objectShape) {
  let found = null;
  function walk(node) {
    if (node.path === path) {
      found = node;
      return;
    }
    (node.children || []).forEach(walk);
  }
  walk(schema);
  return found;
}

function getParentPath(path) {
  const trail = getSchemaPath(path);
  return trail.length > 1 ? trail[trail.length - 2].path : '$';
}

function getFieldReport(path) {
  return lineageReport.fields.find((field) => field.path === path);
}

function getDescendantFields(path, schema = lineageReport.objectShape) {
  const root = findSchemaNode(path, schema) || schema;
  const fields = [];
  function walk(node) {
    if (node.kind === 'field') fields.push(node);
    (node.children || []).forEach(walk);
  }
  walk(root);
  return fields;
}

function containsField(node) {
  if (node.kind === 'field') return true;
  return (node.children || []).some(containsField);
}

function countFields(node) {
  return getDescendantFields(node.path).length;
}

function getFirstFieldPath(path) {
  const node = findSchemaNode(path);
  if (!node) return lineageReport.fields[0].path;
  if (node.kind === 'field') return node.path;
  return getDescendantFields(node.path)[0]?.path || lineageReport.fields[0].path;
}

function getPathLabel(path) {
  const node = findSchemaNode(path);
  if (!node) return path;
  if (node.path === '$') return lineageReport.object.name;
  return node.path;
}

function collectMatchingPaths(query, confidenceFilter) {
  const q = query.trim().toLowerCase();
  return new Set(
    lineageReport.fields
      .filter((field) => {
        const schemaNode = findSchemaNode(field.path);
        const combined = [field.path, schemaNode?.name, schemaNode?.type, field.description, field.mappingType, field.confidence].filter(Boolean).join(' ').toLowerCase();
        const matchesQuery = !q || combined.includes(q);
        const matchesConfidence = confidenceFilter === 'all' || field.confidence === confidenceFilter;
        return matchesQuery && matchesConfidence;
      })
      .map((field) => field.path)
  );
}

function getLineageRowBounds(field) {
  const report = getFieldReport(field.path);
  const rows = (report?.lineage?.nodes || []).map((node) => node.row || 0);
  const min = Math.min(0, ...rows);
  const max = Math.max(0, ...rows);
  return { min, max };
}

function LineageNode({ data, selected }) {
  const isTerminal = TERMINAL_KINDS.has(data.kind);
  const isShape = ['object', 'group', 'array', 'field'].includes(data.kind) && data.section === 'shape';
  const isSubtree = data.view === 'subtree';
  return (
    <div className={cx('node-card', `node-${data.kind}`, selected && 'selected', isTerminal && 'terminal', isShape && 'shape-node', isSubtree && 'subtree-node')}>
      <Handle type="target" position={Position.Left} className="node-handle" />
      <div className="node-topline">
        <span className="node-symbol">{KIND_SYMBOLS[data.kind] || 'node'}</span>
        <span className="node-kind">{KIND_LABELS[data.kind] || data.kind}</span>
        {data.confidence && <span className={cx('node-confidence', confidenceClass(data.confidence))}>{data.confidence}</span>}
      </div>
      <div className="node-title">{data.title}</div>
      {data.subtitle && <div className="node-subtitle">{data.subtitle}</div>}
      {data.meta && <div className="node-meta">{data.meta}</div>}
      <Handle type="source" position={Position.Right} className="node-handle" />
    </div>
  );
}

function LineageEdge({ id, sourceX, sourceY, targetX, targetY, sourcePosition, targetPosition, markerEnd, data, selected }) {
  const [edgePath, labelX, labelY] = getBezierPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
    curvature: data?.hierarchy ? 0.14 : 0.22,
  });
  const label = selected || data?.showLabel;
  return (
    <>
      <BaseEdge
        id={id}
        path={edgePath}
        markerEnd={markerEnd}
        className={cx('lineage-edge', `edge-${data?.category || 'flow'}`, data?.emphasis && 'edge-emphasis', data?.hierarchy && 'edge-hierarchy')}
      />
      {label && (
        <EdgeLabelRenderer>
          <div className="edge-label" style={{ transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)` }}>
            {data?.label}
          </div>
        </EdgeLabelRenderer>
      )}
    </>
  );
}

const nodeTypes = { lineage: LineageNode };
const edgeTypes = { lineage: LineageEdge };

function addSchemaPathNodes(fieldPath, nodes, edges) {
  const schemaPath = getSchemaPath(fieldPath);
  schemaPath.forEach((item, index) => {
    const kind = normalizeKind(item);
    const id = index === schemaPath.length - 1 ? 'FIELD' : `shape::${item.path}`;
    const fieldReport = item.kind === 'field' ? getFieldReport(item.path) : null;
    nodes.push({
      id,
      type: 'lineage',
      position: { x: index * X_STEP, y: 0 },
      data: {
        section: 'shape',
        kind,
        title: item.name,
        subtitle: item.type,
        meta: item.path === '$' ? lineageReport.object.package : item.path,
        field: item.path,
        confidence: fieldReport?.confidence,
        mappingType: fieldReport?.mappingType,
      },
    });
    if (index > 0) {
      edges.push({
        id: `shape-edge-${index}`,
        source: index === 1 ? 'shape::$' : `shape::${schemaPath[index - 1].path}`,
        target: id,
        type: 'lineage',
        markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 },
        data: { label: 'contains', category: 'contains', hierarchy: true, showLabel: false },
      });
    }
  });
  return schemaPath;
}

function buildFocusedLineageGraph(fieldPath) {
  const field = getFieldReport(fieldPath) || lineageReport.fields[0];
  const nodes = [];
  const edges = [];
  const schemaPath = addSchemaPathNodes(field.path, nodes, edges);
  const startX = schemaPath.length * X_STEP + 40;
  const lineageNodes = field.lineage?.nodes || [];
  const lineageEdges = field.lineage?.edges || [];

  lineageNodes.forEach((node) => {
    nodes.push({
      id: `lineage::${node.id}`,
      type: 'lineage',
      position: { x: startX + node.tier * X_STEP, y: node.row * Y_STEP },
      data: {
        section: 'lineage',
        kind: node.kind,
        title: node.title,
        subtitle: node.subtitle,
        meta: node.meta,
        field: field.path,
      },
    });
  });

  lineageEdges.forEach(([from, to, label], index) => {
    const source = from === 'FIELD' ? 'FIELD' : `lineage::${from}`;
    const target = to === 'FIELD' ? 'FIELD' : `lineage::${to}`;
    const targetNode = lineageNodes.find((node) => node.id === to);
    const emphasis = label.includes('computed') || label === 'input' || TERMINAL_KINDS.has(targetNode?.kind);
    edges.push({
      id: `lineage-edge-${index}-${source}-${target}`,
      source,
      target,
      type: 'lineage',
      markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 },
      data: { label, category: edgeCategory(label, targetNode?.kind), emphasis, showLabel: false },
    });
  });

  return { nodes, edges };
}

function buildObjectShapeGraph(matchingPaths) {
  const nodes = [];
  const edges = [];
  const leafY = new Map();
  let yCursor = 0;

  function layout(node) {
    const children = node.children || [];
    if (!children.length) {
      const y = yCursor * 96;
      yCursor += 1;
      leafY.set(node.path, y);
      return { y, count: 1 };
    }
    const childLayouts = children.map((child) => layout(child));
    const y = childLayouts.reduce((sum, child) => sum + child.y, 0) / childLayouts.length;
    leafY.set(node.path, y);
    return { y, count: childLayouts.reduce((sum, child) => sum + child.count, 0) };
  }

  layout(lineageReport.objectShape);

  function visibleBySearch(node) {
    if (node.kind === 'field') return matchingPaths.has(node.path);
    return (node.children || []).some(visibleBySearch) || node.path === '$';
  }

  function walk(node, depth, parentId = null) {
    if (!visibleBySearch(node)) return;
    const fieldReport = node.kind === 'field' ? getFieldReport(node.path) : null;
    const kind = normalizeKind(node);
    const id = `shapeMap::${node.path}`;
    nodes.push({
      id,
      type: 'lineage',
      position: { x: depth * 285, y: leafY.get(node.path) || 0 },
      data: {
        section: 'shape',
        kind,
        title: node.name,
        subtitle: node.type,
        meta: node.path,
        field: node.path,
        confidence: fieldReport?.confidence,
        mappingType: fieldReport?.mappingType,
      },
    });
    if (parentId) {
      edges.push({
        id: `shape-map-edge-${parentId}-${id}`,
        source: parentId,
        target: id,
        type: 'lineage',
        markerEnd: { type: MarkerType.ArrowClosed, width: 15, height: 15 },
        data: { label: 'contains', category: 'contains', hierarchy: true, showLabel: false },
      });
    }
    (node.children || []).forEach((child) => walk(child, depth + 1, id));
  }

  walk(lineageReport.objectShape, 0);
  return { nodes, edges };
}

function buildSelectedObjectLineageGraph(selectedPath, matchingPaths) {
  const selectedNode = findSchemaNode(selectedPath) || lineageReport.objectShape;
  if (selectedNode.kind === 'field') return buildFocusedLineageGraph(selectedPath);

  const allLeaves = getDescendantFields(selectedNode.path).filter((leaf) => matchingPaths.has(leaf.path));
  const leaves = allLeaves.length ? allLeaves : getDescendantFields(selectedNode.path);
  const laneBaseY = new Map();
  const laneStats = new Map();
  let cursor = 0;

  leaves.forEach((leaf) => {
    const { min, max } = getLineageRowBounds(leaf);
    const base = cursor + Math.max(0, -min) * SUBTREE_BRANCH_Y + 22;
    const height = (max - min) * SUBTREE_BRANCH_Y + 170;
    laneBaseY.set(leaf.path, base);
    laneStats.set(leaf.path, { min, max, base, height, top: cursor });
    cursor += height + SUBTREE_LANE_GAP;
  });

  const nodes = [];
  const edges = [];
  const visibleLeaves = new Set(leaves.map((leaf) => leaf.path));

  function hasVisibleLeaf(node) {
    if (node.kind === 'field') return visibleLeaves.has(node.path);
    return (node.children || []).some(hasVisibleLeaf);
  }

  function relativeDepth(nodePath) {
    const rootTrail = getSchemaPath(selectedNode.path);
    const nodeTrail = getSchemaPath(nodePath);
    return Math.max(0, nodeTrail.length - rootTrail.length);
  }

  function nodeY(node) {
    if (node.kind === 'field') return laneBaseY.get(node.path) || 0;
    const childYs = (node.children || []).filter(hasVisibleLeaf).map(nodeY);
    if (!childYs.length) return 0;
    return childYs.reduce((sum, y) => sum + y, 0) / childYs.length;
  }

  function walkShape(node, parentId = null) {
    if (!hasVisibleLeaf(node)) return;
    const id = `subshape::${node.path}`;
    const fieldReport = node.kind === 'field' ? getFieldReport(node.path) : null;
    nodes.push({
      id,
      type: 'lineage',
      position: { x: relativeDepth(node.path) * X_STEP, y: nodeY(node) },
      data: {
        section: 'shape',
        view: 'subtree',
        kind: normalizeKind(node),
        title: node.name,
        subtitle: node.type,
        meta: node.path === '$' ? lineageReport.object.package : node.path,
        field: node.path,
        confidence: fieldReport?.confidence,
        mappingType: fieldReport?.mappingType,
      },
    });
    if (parentId) {
      edges.push({
        id: `subshape-edge-${parentId}-${id}`,
        source: parentId,
        target: id,
        type: 'lineage',
        markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 },
        data: { label: 'contains', category: 'contains', hierarchy: true, showLabel: false },
      });
    }
    (node.children || []).forEach((child) => walkShape(child, id));
  }

  walkShape(selectedNode);

  const maxShapeDepth = leaves.reduce((max, leaf) => Math.max(max, relativeDepth(leaf.path)), 0);
  const lineageStartX = (maxShapeDepth + 1) * X_STEP + 58;

  leaves.forEach((leaf, leafIndex) => {
    const field = getFieldReport(leaf.path);
    if (!field?.lineage) return;
    const baseY = laneBaseY.get(leaf.path) || 0;
    const lineageNodes = field.lineage.nodes || [];
    const lineageEdges = field.lineage.edges || [];

    lineageNodes.forEach((node) => {
      nodes.push({
        id: `sublineage::${leaf.path}::${node.id}`,
        type: 'lineage',
        position: { x: lineageStartX + node.tier * X_STEP, y: baseY + (node.row || 0) * SUBTREE_BRANCH_Y },
        data: {
          section: 'lineage',
          view: 'subtree',
          kind: node.kind,
          title: node.title,
          subtitle: node.subtitle,
          meta: node.meta,
          field: field.path,
        },
      });
    });

    lineageEdges.forEach(([from, to, label], index) => {
      const source = from === 'FIELD' ? `subshape::${leaf.path}` : `sublineage::${leaf.path}::${from}`;
      const target = to === 'FIELD' ? `subshape::${leaf.path}` : `sublineage::${leaf.path}::${to}`;
      const targetNode = lineageNodes.find((node) => node.id === to);
      const emphasis = label.includes('computed') || label === 'input' || TERMINAL_KINDS.has(targetNode?.kind);
      edges.push({
        id: `sublineage-edge-${leafIndex}-${index}-${source}-${target}`,
        source,
        target,
        type: 'lineage',
        markerEnd: { type: MarkerType.ArrowClosed, width: 16, height: 16 },
        data: { label, category: edgeCategory(label, targetNode?.kind), emphasis, showLabel: false },
      });
    });
  });

  return { nodes, edges };
}

function containsMatchingField(node, matchingPaths) {
  if (node.kind === 'field') return matchingPaths.has(node.path);
  return (node.children || []).some((child) => containsMatchingField(child, matchingPaths));
}

function TreeItem({ node, depth, selectedPath, matchingPaths, onSelect, queryActive }) {
  const [open, setOpen] = useState(true);
  const children = node.children || [];
  const fieldReport = node.kind === 'field' ? getFieldReport(node.path) : null;
  const hasMatchingChild = children.some((child) => containsMatchingField(child, matchingPaths));
  const isMatchedField = node.kind === 'field' && matchingPaths.has(node.path);
  const hiddenByFilter = queryActive && !isMatchedField && !hasMatchingChild && node.path !== '$';
  if (hiddenByFilter) return null;

  const isContainer = node.kind !== 'field';
  const leafCount = isContainer ? countFields(node) : 0;
  return (
    <div className="tree-item">
      <button
        className={cx('tree-row', `tree-${normalizeKind(node)}`, selectedPath === node.path && 'active', isContainer && 'container-row')}
        style={{ paddingLeft: 10 + depth * 16 }}
        onClick={() => onSelect(node)}
        title={isContainer ? 'Select object to show descendant lineage graph' : 'Select field to show focused lineage trace'}
      >
        <span
          className="twisty"
          onClick={(event) => {
            if (!children.length) return;
            event.stopPropagation();
            setOpen(!open);
          }}
        >
          {children.length ? (open ? '▾' : '▸') : ''}
        </span>
        <span className={cx('tree-icon', mapTypeClass(fieldReport?.mappingType || node.kind))}>{node.kind === 'array' ? '[]' : node.kind === 'field' ? '•' : '{}'}</span>
        <span className="tree-main">
          <strong>{node.name}</strong>
          <em>{node.type}</em>
        </span>
        {fieldReport && <span className={cx('tree-confidence', confidenceClass(fieldReport.confidence))}>{fieldReport.confidence[0].toUpperCase()}</span>}
        {isContainer && <span className="tree-count">{leafCount}</span>}
      </button>
      {open && children.map((child) => (
        <TreeItem
          key={child.path}
          node={child}
          depth={depth + 1}
          selectedPath={selectedPath}
          matchingPaths={matchingPaths}
          onSelect={onSelect}
          queryActive={queryActive}
        />
      ))}
    </div>
  );
}


function LegendDrawer({ onClose }) {
  return (
    <div className="legend-drawer">
      <div className="legend-head">
        <div>
          <div className="eyebrow">Graph legend</div>
          <h3>How to read the lineage graph</h3>
        </div>
        <button className="icon-button" onClick={onClose} aria-label="Close legend">×</button>
      </div>

      <div className="legend-section">
        <div className="legend-title">Node types</div>
        <div className="legend-grid">
          {NODE_LEGEND.map((item) => (
            <div className="legend-row" key={item.kind}>
              <span className={cx('legend-node-symbol', `node-${item.kind}`)}>{KIND_SYMBOLS[item.kind] || 'node'}</span>
              <span>
                <strong>{item.label}</strong>
                <em>{item.text}</em>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="legend-section">
        <div className="legend-title">Edge types</div>
        <div className="legend-grid edge-legend-grid">
          {EDGE_LEGEND.map((item) => (
            <div className="legend-row" key={item.key}>
              <span className={cx('legend-edge-swatch', `edge-${item.key}`)} />
              <span>
                <strong>{item.label}</strong>
                <em>{item.text}</em>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="legend-note">
        Edge labels are hidden by default to prevent overlap. Select an edge to reveal its label, or inspect a node in the right panel for source evidence.
      </div>
    </div>
  );
}

function AppInner() {
  const allFields = useMemo(() => getAllFields(), []);
  const [query, setQuery] = useState('');
  const [confidenceFilter, setConfidenceFilter] = useState('all');
  const [selectedPath, setSelectedPath] = useState('financialTerms.paymentToIncomeRatio');
  const [selectedField, setSelectedField] = useState('financialTerms.paymentToIncomeRatio');
  const [graphMode, setGraphMode] = useState('lineage');
  const [selectedNode, setSelectedNode] = useState(null);
  const [legendOpen, setLegendOpen] = useState(false);
  const { fitView } = useReactFlow();

  const matchingPaths = useMemo(() => collectMatchingPaths(query, confidenceFilter), [query, confidenceFilter]);
  const visibleFieldReports = useMemo(() => lineageReport.fields.filter((field) => matchingPaths.has(field.path)), [matchingPaths]);

  useEffect(() => {
    const selectedSchema = findSchemaNode(selectedPath);
    if (selectedSchema?.kind === 'field' && !matchingPaths.has(selectedPath) && visibleFieldReports.length) {
      setSelectedPath(visibleFieldReports[0].path);
      setSelectedField(visibleFieldReports[0].path);
      setGraphMode('lineage');
    }
    if (selectedSchema?.kind !== 'field') {
      const leaves = getDescendantFields(selectedPath).filter((leaf) => matchingPaths.has(leaf.path));
      if (!leaves.length && visibleFieldReports.length) {
        const next = getParentPath(visibleFieldReports[0].path);
        setSelectedPath(next);
        setSelectedField(visibleFieldReports[0].path);
        setGraphMode('subtree');
      }
    }
  }, [matchingPaths, selectedPath, visibleFieldReports]);

  const selectedSchema = findSchemaNode(selectedPath) || lineageReport.objectShape;
  const selectedLeaves = useMemo(() => getDescendantFields(selectedPath), [selectedPath]);
  const selectedVisibleLeaves = useMemo(() => selectedLeaves.filter((leaf) => matchingPaths.has(leaf.path)), [selectedLeaves, matchingPaths]);
  const effectiveSelectedField = selectedSchema.kind === 'field' ? selectedPath : selectedField || getFirstFieldPath(selectedPath);

  const graph = useMemo(() => {
    if (graphMode === 'shape') return buildObjectShapeGraph(matchingPaths);
    if (graphMode === 'subtree') return buildSelectedObjectLineageGraph(selectedPath, matchingPaths);
    return buildFocusedLineageGraph(effectiveSelectedField);
  }, [graphMode, selectedPath, effectiveSelectedField, matchingPaths]);

  const [nodes, setNodes, onNodesChange] = useNodesState(graph.nodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(graph.edges);

  useEffect(() => {
    setNodes(graph.nodes);
    setEdges(graph.edges);
    setSelectedNode(null);
    requestAnimationFrame(() => fitView({ padding: graphMode === 'subtree' ? 0.08 : graphMode === 'shape' ? 0.18 : 0.12, duration: 350 }));
  }, [graph.nodes, graph.edges, setNodes, setEdges, fitView, graphMode]);

  const selectedFieldReport = getFieldReport(effectiveSelectedField) || lineageReport.fields[0];
  const selectedFieldSchema = findSchemaNode(effectiveSelectedField);
  const schemaPath = getSchemaPath(selectedPath);
  const selectedData = selectedNode?.data || null;
  const isFieldSelection = selectedSchema.kind === 'field';
  const modeDescription = getModeDescription(graphMode, isFieldSelection);
  const modeLabel = graphMode === 'shape' ? 'Shape' : graphMode === 'subtree' ? 'Object lineage' : 'Field trace';
  const targetLabel = graphMode === 'shape'
    ? lineageReport.object.name
    : graphMode === 'subtree'
      ? getPathLabel(selectedPath)
      : effectiveSelectedField;
  const breadcrumbLabel = schemaPath.map((node) => node.name).join(' › ');
  const showBreadcrumb = breadcrumbLabel && breadcrumbLabel !== targetLabel && !(graphMode === 'subtree' && selectedPath === '$');

  const onTreeSelect = (node) => {
    setSelectedPath(node.path);
    if (node.kind === 'field') {
      setSelectedField(node.path);
      setGraphMode('lineage');
    } else {
      const firstLeaf = getDescendantFields(node.path).find((leaf) => matchingPaths.has(leaf.path)) || getDescendantFields(node.path)[0];
      if (firstLeaf) setSelectedField(firstLeaf.path);
      setGraphMode('subtree');
    }
  };

  const onNodeClick = useCallback((_, node) => {
    setSelectedNode(node);
    if (node.data?.section === 'shape' && node.data?.field) {
      const schema = findSchemaNode(node.data.field);
      if (!schema) return;
      setSelectedPath(schema.path);
      if (schema.kind === 'field' && getFieldReport(schema.path)) {
        setSelectedField(schema.path);
        if (graphMode === 'shape' || graphMode === 'subtree') setGraphMode('lineage');
      } else if (schema.kind !== 'field') {
        const firstLeaf = getDescendantFields(schema.path)[0];
        if (firstLeaf) setSelectedField(firstLeaf.path);
        if (graphMode === 'shape') setGraphMode('subtree');
      }
    }
  }, [graphMode]);

  const showGaps = () => {
    const low = lineageReport.fields.find((field) => field.confidence === 'low');
    if (low) {
      setSelectedPath(low.path);
      setSelectedField(low.path);
      setGraphMode('lineage');
      setConfidenceFilter('all');
      setQuery('');
    }
  };

  const selectedObjectSummary = isFieldSelection
    ? `${selectedFieldReport.mappingType} field trace`
    : `${selectedVisibleLeaves.length || selectedLeaves.length} descendant leaf fields`;

  return (
    <div className="app-shell">
      <aside className="left-rail">
        <div className="brand-block">
          <div className="brand-kicker">Object Lineage</div>
          <h1>{lineageReport.object.name}</h1>
          <div className="surface-pill">{lineageReport.object.outboundSurface.transport}</div>
        </div>

        <div className="summary-grid">
          <div><strong>{lineageReport.summary.fieldsFound}</strong><span>Fields</span></div>
          <div><strong>{lineageReport.summary.highConfidence}</strong><span>High</span></div>
          <div><strong>{lineageReport.summary.mediumConfidence}</strong><span>Med</span></div>
          <div><strong>{lineageReport.summary.lowConfidence}</strong><span>Low</span></div>
        </div>

        <div className="control-block">
          <label>Search object shape</label>
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="field, type, source, risk..." />
        </div>

        <div className="segmented">
          {['all','high','medium','low'].map((value) => (
            <button key={value} className={confidenceFilter === value ? 'active' : ''} onClick={() => setConfidenceFilter(value)}>{value}</button>
          ))}
        </div>

        <div className="hierarchy-head">
          <span>Object hierarchy</span>
          <small>{visibleFieldReports.length}/{allFields.length} leaf fields</small>
        </div>

        <div className="object-tree">
          <TreeItem
            node={lineageReport.objectShape}
            depth={0}
            selectedPath={selectedPath}
            matchingPaths={matchingPaths}
            onSelect={onTreeSelect}
            queryActive={Boolean(query.trim()) || confidenceFilter !== 'all'}
          />
        </div>
      </aside>

      <main className="canvas-wrap">
        <div className="topbar compact-topbar">
          <div className="topbar-left" title={modeDescription}>
            <span className="mode-pill compact">{modeLabel}</span>
            <div className="topbar-copy">
              <div className="topbar-title">{targetLabel}</div>
              {showBreadcrumb && <div className="breadcrumb compact">{breadcrumbLabel}</div>}
            </div>
          </div>
          <div className="topbar-actions">
            <div className="view-switcher" aria-label="View mode">
              <button title="Show one selected field trace" className={graphMode === 'lineage' ? 'active' : ''} onClick={() => { setSelectedPath(effectiveSelectedField); setGraphMode('lineage'); }}>Field</button>
              <button title="Show all descendant field traces under the selected object" className={graphMode === 'subtree' ? 'active' : ''} onClick={() => { if (isFieldSelection) setSelectedPath(getParentPath(effectiveSelectedField)); setGraphMode('subtree'); }}>Object</button>
              <button title="Show nested object shape only" className={graphMode === 'shape' ? 'active' : ''} onClick={() => setGraphMode('shape')}>Shape</button>
            </div>
            <button className={cx('utility-action', legendOpen && 'active')} title="Open legend" onClick={() => setLegendOpen((open) => !open)}>Legend</button>
            <button className="utility-action" title="Fit graph to view" onClick={() => fitView({ padding: 0.14, duration: 350 })}>Fit</button>
            <button className="utility-action" title="Jump to unresolved/low confidence fields" onClick={showGaps}>Gaps</button>
          </div>
        </div>

        {legendOpen && <LegendDrawer onClose={() => setLegendOpen(false)} />}

        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          edgeTypes={edgeTypes}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onNodeClick={onNodeClick}
          fitView
          minZoom={0.12}
          maxZoom={1.7}
          nodesDraggable
          proOptions={{ hideAttribution: true }}
          defaultEdgeOptions={{ interactionWidth: 22 }}
        >
          <Background color="#d7e0eb" gap={24} size={1} />
          <Controls position="bottom-left" />
          <MiniMap
            position="bottom-right"
            pannable
            zoomable
            nodeBorderRadius={10}
            nodeColor={(node) => {
              const kind = node.data?.kind;
              if (kind === 'field') return '#2563eb';
              if (kind === 'transform') return '#7c3aed';
              if (kind === 'array') return '#0f766e';
              if (kind === 'group' || kind === 'object') return '#475569';
              if (kind === 'unknown') return '#b42318';
              if (TERMINAL_KINDS.has(kind)) return '#047857';
              return '#94a3b8';
            }}
          />
        </ReactFlow>
      </main>

      <aside className="inspector">
        <div className="inspector-card primary">
          <div className="eyebrow">Selected {isFieldSelection ? 'leaf field' : selectedSchema.kind === 'array' ? 'list' : 'object'}</div>
          <h2>{getPathLabel(selectedPath)}</h2>
          <p>{isFieldSelection ? selectedFieldReport.description : `Showing the full lineage graph under this node. ${selectedObjectSummary} are included as separate lanes so nested fields stay readable.`}</p>
          <div className="tag-row">
            <span>{selectedSchema?.type}</span>
            <span>{isFieldSelection ? selectedFieldReport.mappingType : selectedSchema.kind}</span>
            {isFieldSelection && <span className={confidenceClass(selectedFieldReport.confidence)}>{selectedFieldReport.confidence} confidence</span>}
            {!isFieldSelection && <span>{selectedVisibleLeaves.length || selectedLeaves.length} fields below</span>}
          </div>
        </div>

        {!isFieldSelection && (
          <div className="inspector-card compact-list field-bucket">
            <div className="eyebrow">Fields in selected object</div>
            {(selectedVisibleLeaves.length ? selectedVisibleLeaves : selectedLeaves).slice(0, 12).map((leaf) => {
              const report = getFieldReport(leaf.path);
              return <button key={leaf.path} onClick={() => { setSelectedPath(leaf.path); setSelectedField(leaf.path); setGraphMode('lineage'); }} className={cx('field-chip', confidenceClass(report?.confidence))}>{leaf.path}</button>;
            })}
            {(selectedVisibleLeaves.length ? selectedVisibleLeaves : selectedLeaves).length > 12 && <span>+{(selectedVisibleLeaves.length ? selectedVisibleLeaves : selectedLeaves).length - 12} more</span>}
          </div>
        )}

        <div className="inspector-card">
          <div className="eyebrow">Object path</div>
          <div className="path-stack">
            {schemaPath.map((node) => (
              <div key={node.path} className={cx('path-row', `path-${normalizeKind(node)}`)}>
                <span>{node.kind === 'array' ? '[]' : node.kind === 'field' ? '•' : '{}'}</span>
                <strong>{node.name}</strong>
                <em>{node.type}</em>
              </div>
            ))}
          </div>
        </div>

        <div className="inspector-card">
          <div className="eyebrow">Selected graph node</div>
          {selectedData ? (
            <>
              <h3>{selectedData.title}</h3>
              <p>{selectedData.subtitle}</p>
              <dl>
                <dt>Type</dt><dd>{KIND_LABELS[selectedData.kind]}</dd>
                <dt>Path</dt><dd>{selectedData.field}</dd>
                <dt>Evidence</dt><dd>{selectedData.meta || 'No source evidence attached'}</dd>
              </dl>
            </>
          ) : (
            <p>Click a graph node to inspect its file, method, type, boundary, or evidence.</p>
          )}
        </div>

        <div className="inspector-card">
          <div className="eyebrow">Overlap controls used</div>
          <p>Object lineage mode uses vertical field lanes, wide tier spacing, hidden edge labels, and a separate inspector so full descendant traces stay easier to follow.</p>
        </div>

        <div className="inspector-card compact-list">
          <div className="eyebrow">Primary origins</div>
          {lineageReport.summary.primaryOrigins.map((origin) => <span key={origin}>{origin}</span>)}
        </div>
      </aside>
    </div>
  );
}

function App() {
  return (
    <ReactFlowProvider>
      <AppInner />
    </ReactFlowProvider>
  );
}

createRoot(document.getElementById('root')).render(<App />);
